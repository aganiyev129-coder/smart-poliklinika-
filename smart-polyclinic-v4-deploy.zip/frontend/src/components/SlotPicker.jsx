import React from 'react';
import { genSlots } from '../utils/helpers';

export default function SlotPicker({ start, end, takenSlots = [], selected, onSelect, portalStyle }) {
  const slots = genSlots(start, end);

  return (
    <div className={`slots-grid${portalStyle ? ' portal-slots' : ''}`}>
      {slots.map(t => {
        const taken = takenSlots.includes(t);
        return (
          <div
            key={t}
            className={`slot${taken ? ' taken' : ''}${selected === t ? ' selected' : ''}`}
            onClick={() => !taken && onSelect(t)}
          >
            {t}
          </div>
        );
      })}
    </div>
  );
}
