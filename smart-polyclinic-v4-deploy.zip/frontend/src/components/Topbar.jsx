import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const PAGE_TITLES = {
  '/app/admin/dashboard': 'Bosh sahifa',
  '/app/admin/doctors': 'Shifokorlar',
  '/app/admin/patients': 'Bemorlar',
  '/app/admin/users': 'Foydalanuvchilar',
  '/app/admin/reports': 'Hisobotlar',
  '/app/admin/logs': 'Faoliyat jurnali',
  '/app/admin/settings': 'Sozlamalar',
  '/app/registrar/dashboard': 'Bosh sahifa',
  '/app/registrar/patients': 'Bemorlar',
  '/app/registrar/appointments': 'Qabullar',
  '/app/registrar/payment': "To'lov va cheklar",
  '/app/doctor/dashboard': 'Bosh sahifa',
  '/app/doctor/patients': 'Mening bemorlarim',
  '/app/doctor/appointments': 'Mening qabullarim',
  '/app/doctor/chat': 'Onlayn maslahat',
  '/app/ai': 'AI Yordamchi',
};

export default function Topbar({ onMenuClick }) {
  const location = useLocation();
  const [time, setTime] = useState('');
  const [date, setDate] = useState('');
  const [lunchBan, setLunchBan] = useState(false);

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' }));
      setDate(now.toLocaleDateString('uz-UZ', { day: '2-digit', month: 'short' }));
      const h = now.getHours(), m = now.getMinutes();
      setLunchBan(h === 13 && m < 30);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const title = PAGE_TITLES[location.pathname] || 'Sahifa';

  return (
    <div className="topbar">
      <button className="btn menu-btn" onClick={onMenuClick} style={{ padding: '8px' }}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
        </svg>
      </button>
      <div className="topbar-title">{title}</div>
      {lunchBan && (
        <div className="lunch-ban" style={{ fontSize: '.72rem' }}>
          ⚠️ Tushlik tanaffusi — 13:00–13:30
        </div>
      )}
      <div className="topbar-clock">
        <strong>{time}</strong>
        {date}
      </div>
    </div>
  );
}
