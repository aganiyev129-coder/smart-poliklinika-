import React from 'react';
import { statusLabel, statusClass } from '../utils/helpers';

export function StatusBadge({ status }) {
  return <span className={`badge ${statusClass(status)}`}>{statusLabel(status)}</span>;
}

export function Badge({ children, type = 'info' }) {
  return <span className={`badge badge-${type}`}>{children}</span>;
}
