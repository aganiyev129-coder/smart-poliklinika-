import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { notify } from './Notify';
import { ROLE_NAMES } from '../utils/constants';

const ROLE_NAV = {
  superadmin: [
    { section: 'Asosiy', items: [
      { to: '/app/admin/dashboard', label: 'Bosh sahifa', icon: '📊' },
      { to: '/app/admin/doctors', label: 'Shifokorlar', icon: '👨‍⚕️' },
      { to: '/app/admin/patients', label: 'Bemorlar', icon: '👥' },
    ]},
    { section: 'Tizim', items: [
      { to: '/app/admin/users', label: 'Foydalanuvchilar', icon: '🔑' },
      { to: '/app/admin/reports', label: 'Hisobotlar', icon: '📈' },
      { to: '/app/admin/logs', label: 'Jurnal', icon: '📋' },
      { to: '/app/admin/settings', label: 'Sozlamalar', icon: '⚙️' },
    ]}
  ],
  registrar: [
    { section: 'Asosiy', items: [
      { to: '/app/registrar/dashboard', label: 'Bosh sahifa', icon: '📊' },
      { to: '/app/registrar/patients', label: 'Bemorlar', icon: '👥' },
      { to: '/app/registrar/appointments', label: 'Qabullar', icon: '📅' },
      { to: '/app/registrar/payment', label: "To'lov / Chek", icon: '💳' },
    ]},
    { section: "Qo'shimcha", items: [
      { to: '/app/ai', label: 'AI Yordamchi', icon: '🤖' },
    ]}
  ],
  doctor: [
    { section: 'Asosiy', items: [
      { to: '/app/doctor/dashboard', label: 'Bosh sahifa', icon: '📊' },
      { to: '/app/doctor/patients', label: 'Mening bemorlarim', icon: '👥' },
      { to: '/app/doctor/appointments', label: 'Mening qabullarim', icon: '📅' },
    ]},
    { section: 'Xizmat', items: [
      { to: '/app/doctor/chat', label: 'Onlayn maslahat', icon: '💬' },
      { to: '/app/ai', label: 'AI Yordamchi', icon: '🤖' },
    ]}
  ]
};

export default function Sidebar({ onClose }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const groups = ROLE_NAV[user?.role] || [];

  const handleLogout = () => {
    logout();
    notify('Tizimdan chiqildi', 'info');
    navigate('/login');
  };

  return (
    <div className="sidebar">
      <div className="sidebar-head">
        <div className="sidebar-brand">
          <div className="sidebar-logo">🏥</div>
          <div>
            <div className="sidebar-brand-name">Aqlli Poliklinika</div>
            <div className="sidebar-brand-sub">Tizim v4.0</div>
          </div>
        </div>
        <div className="sidebar-user">
          <div className="sidebar-avatar">
            {user?.photo ? <img src={user.photo} alt="" /> : (user?.firstName || 'U')[0]}
          </div>
          <div>
            <div className="sidebar-uname">{user?.firstName} {user?.lastName}</div>
            <div className="sidebar-urole">{ROLE_NAMES[user?.role] || user?.role}</div>
          </div>
        </div>
      </div>

      <nav className="sidebar-nav">
        {groups.map(g => (
          <div className="nav-group" key={g.section}>
            <div className="nav-group-label">{g.section}</div>
            {g.items.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}
                onClick={onClose}
              >
                <span className="nav-item-ic">{item.icon}</span>
                {item.label}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      <div className="sidebar-foot">
        <button className="btn btn-outline btn-block btn-sm" onClick={handleLogout}>
          🚪 Chiqish
        </button>
      </div>
    </div>
  );
}
