import React, { useState, useCallback } from 'react';

let globalNotify = null;

export function NotifyContainer() {
  const [items, setItems] = useState([]);

  globalNotify = useCallback((msg, type = 'info') => {
    const id = Date.now();
    setItems(p => [...p, { id, msg, type }]);
    setTimeout(() => setItems(p => p.filter(x => x.id !== id)), 3500);
  }, []);

  const icons = { success: '✓', danger: '✕', warning: '!', info: 'i' };

  return (
    <div className="notif-box">
      {items.map(item => (
        <div key={item.id} className={`notif ${item.type}`}>
          <span className="notif-ico">{icons[item.type] || 'i'}</span>
          <span>{item.msg}</span>
        </div>
      ))}
    </div>
  );
}

export function notify(msg, type = 'info') {
  globalNotify?.(msg, type);
}
