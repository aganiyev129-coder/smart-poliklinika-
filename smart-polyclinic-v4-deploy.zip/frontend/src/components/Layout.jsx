import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import { NotifyContainer } from './Notify';

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="app-shell">
      <div className={`sidebar-overlay${sidebarOpen ? ' show' : ''}`} onClick={() => setSidebarOpen(false)} />
      <div className={sidebarOpen ? 'sidebar open' : 'sidebar'} style={sidebarOpen ? undefined : undefined}>
        <Sidebar onClose={() => setSidebarOpen(false)} />
      </div>
      <div className="main-area">
        <Topbar onMenuClick={() => setSidebarOpen(o => !o)} />
        <div className="page-content">
          <Outlet />
        </div>
      </div>
      <NotifyContainer />
    </div>
  );
}
