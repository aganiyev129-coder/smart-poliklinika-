import React from 'react';

export default function EmptyState({ icon = '—', text = 'Ma\'lumot yo\'q' }) {
  return (
    <div className="empty-st">
      <div className="empty-st-ic">{icon}</div>
      <h3>{text}</h3>
    </div>
  );
}
