import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';

const SocketContext = createContext(null);

export function SocketProvider({ children }) {
  const socketRef = useRef(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const backendUrl = import.meta.env.VITE_BACKEND_URL || 'http://localhost:3001';
    socketRef.current = io(backendUrl, {
      auth: { token: token || '' },
      autoConnect: true
    });
    socketRef.current.on('connect', () => setConnected(true));
    socketRef.current.on('disconnect', () => setConnected(false));
    return () => socketRef.current?.disconnect();
  }, []);

  const joinChat = (chatKey) => socketRef.current?.emit('join-chat', chatKey);
  const sendMessage = (chatKey, message) => socketRef.current?.emit('send-message', { chatKey, message });
  const onMessage = (cb) => {
    socketRef.current?.on('new-message', cb);
    return () => socketRef.current?.off('new-message', cb);
  };

  return (
    <SocketContext.Provider value={{ connected, joinChat, sendMessage, onMessage, socket: socketRef.current }}>
      {children}
    </SocketContext.Provider>
  );
}

export const useSocket = () => useContext(SocketContext);
