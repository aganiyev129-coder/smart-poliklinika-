import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { io } from 'socket.io-client';
import SlotPicker from '../../components/SlotPicker';
import { NotifyContainer, notify } from '../../components/Notify';
import { formatDate, formatMoney, today } from '../../utils/helpers';
import { StatusBadge, Badge } from '../../components/Badge';
import EmptyState from '../../components/EmptyState';

const portalApi = axios.create({ baseURL: '/api' });

export default function PatientPortal() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('book');
  const [patient, setPatient] = useState(null);
  const [searchQ, setSearchQ] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [guestName, setGuestName] = useState('');
  const [doctors, setDoctors] = useState([]);
  const [selDoc, setSelDoc] = useState(null);
  const [date, setDate] = useState(today());
  const [takenSlots, setTakenSlots] = useState([]);
  const [slot, setSlot] = useState(null);
  const [bookResult, setBookResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [chatDoc, setChatDoc] = useState(null);
  const [chatKey, setChatKey] = useState(null);
  const [messages, setMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const socketRef = useRef(null);
  const msgsRef = useRef(null);

  useEffect(() => {
    portalApi.get('/portal/doctors').then(r => setDoctors(r.data));
    socketRef.current = io('http://localhost:3001', { auth: { token: '' } });
    socketRef.current.on('new-message', msg => setMessages(p => [...p, msg]));
    return () => socketRef.current?.disconnect();
  }, []);

  useEffect(() => {
    if (msgsRef.current) msgsRef.current.scrollTop = msgsRef.current.scrollHeight;
  }, [messages]);

  const searchPatients = async q => {
    setSearchQ(q);
    if (q.length < 2) { setSearchResults([]); return; }
    const r = await portalApi.get('/portal/patients', { params: { q } });
    setSearchResults(r.data);
  };

  const loginAsPatient = p => { setPatient(p); setSearchResults([]); setSearchQ(''); };
  const loginAsGuest = () => {
    if (!guestName.trim()) { notify("Ismingizni kiriting!", 'warning'); return; }
    setPatient({ id: null, firstName: guestName.trim(), lastName: '', isGuest: true });
  };

  const loadSlots = async (docId, d) => {
    if (!docId || !d) return;
    const r = await portalApi.get('/portal/appointments', { params: { patientName: '_no_match_for_slots_' } });
    // get taken from all appointments for this doctor+date
    const all = await portalApi.get('/portal/appointments', { params: { patientName: '' } }).catch(() => ({ data: [] }));
    // We need to query regular appointments endpoint — let's use reports workaround
    const allApts = await portalApi.get('/appointments').catch(() => ({ data: [] }));
    const taken = (allApts.data || []).filter(a => a.doctorId === docId && a.date === d && a.status !== 'cancelled').map(a => a.time);
    setTakenSlots(taken);
  };

  const pickDoc = async doc => {
    setSelDoc(doc); setSlot(null); setBookResult(null);
    await loadSlots(doc.id, date);
  };

  const onDateChange = async e => {
    setDate(e.target.value); setSlot(null);
    if (selDoc) await loadSlots(selDoc.id, e.target.value);
  };

  const book = async () => {
    if (!selDoc || !slot) { notify("Shifokor va vaqtni tanlang!", 'warning'); return; }
    try {
      const r = await portalApi.post('/portal/book', {
        patientId: patient?.id || null,
        patientName: patient ? `${patient.firstName} ${patient.lastName || ''}`.trim() : 'Mehmon',
        doctorId: selDoc.id, doctorName: `${selDoc.firstName} ${selDoc.lastName}`,
        date, time: slot, price: selDoc.price
      });
      setBookResult(r.data);
      notify(`Navbat #${r.data.queue} belgilandi!`, 'success');
      if (patient?.id) loadHistory();
    } catch (e) { notify(e.response?.data?.error || 'Xatolik', 'danger'); }
  };

  const loadHistory = async () => {
    if (!patient) return;
    const p = patient.id ? { patientId: patient.id } : { patientName: `${patient.firstName} ${patient.lastName || ''}`.trim() };
    const r = await portalApi.get('/portal/appointments', { params: p });
    setHistory(r.data);
  };

  const openChat = async doc => {
    if (!patient?.id) { notify("Tarix uchun tizimga kiring!", 'warning'); return; }
    const key = `dp_${doc.id}_${patient.id}`;
    setChatDoc(doc); setChatKey(key);
    socketRef.current?.emit('join-chat', key);
    const r = await portalApi.get(`/chat/${key}`);
    setMessages(r.data);
  };

  const sendChat = () => {
    if (!chatInput.trim() || !chatKey) return;
    const msg = { text: chatInput.trim(), sender: 'patient', isPrescription: false, time: new Date().toISOString() };
    socketRef.current?.emit('send-message', { chatKey, message: msg });
    setChatInput('');
  };

  if (!patient) {
    return (
      <div className="portal-page">
        <div className="portal-topbar">
          <div className="brand">🏥 Aqlli Poliklinika — Bemor portali</div>
          <button className="btn btn-sm" style={{ color: 'rgba(255,255,255,.8)', border: '1px solid rgba(255,255,255,.3)' }} onClick={() => navigate('/login')}>← Orqaga</button>
        </div>
        <div className="portal-content" style={{ maxWidth: 480 }}>
          <div className="portal-card">
            <div className="portal-card-title">👤 Tizimga kirish</div>
            <div className="portal-form">
              <div className="form-group">
                <label className="form-label">Ismingiz yoki telefoningiz bilan qidiring</label>
                <input className="form-control" value={searchQ} onChange={e => searchPatients(e.target.value)} placeholder="Ism yoki telefon..." />
              </div>
              {searchResults.map(p => (
                <div key={p.id} onClick={() => loginAsPatient(p)} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '9px 10px', border: '1px solid rgba(255,255,255,.2)', borderRadius: 6, marginBottom: 6, cursor: 'pointer', background: 'rgba(255,255,255,.05)' }}>
                  <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'rgba(255,255,255,.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700 }}>{p.firstName[0]}</div>
                  <div><div style={{ fontWeight: 600, fontSize: '.85rem', color: '#fff' }}>{p.firstName} {p.lastName}</div><div style={{ fontSize: '.72rem', color: 'rgba(255,255,255,.6)' }}>{p.phone || '—'}</div></div>
                </div>
              ))}
              <hr style={{ borderColor: 'rgba(255,255,255,.2)', margin: '14px 0' }} />
              <div className="form-group">
                <label className="form-label" style={{ color: 'rgba(255,255,255,.8)' }}>Yoki mehmon sifatida kirish</label>
                <input className="form-control" value={guestName} onChange={e => setGuestName(e.target.value)} placeholder="Ismingiz..." />
              </div>
              <button className="btn btn-block" style={{ background: 'rgba(255,255,255,.2)', color: '#fff', border: '1px solid rgba(255,255,255,.3)' }} onClick={loginAsGuest}>Mehmon sifatida kirish</button>
            </div>
          </div>
        </div>
        <NotifyContainer />
      </div>
    );
  }

  return (
    <div className="portal-page">
      <div className="portal-topbar">
        <div className="brand">🏥 Aqlli Poliklinika</div>
        <div style={{ color: 'rgba(255,255,255,.85)', fontSize: '.85rem' }}>Xush kelibsiz, {patient.firstName}! {patient.isGuest && <span style={{ background: 'rgba(255,165,0,.3)', padding: '2px 8px', borderRadius: 10, fontSize: '.72rem' }}>Mehmon</span>}</div>
        <button className="btn btn-sm" style={{ color: 'rgba(255,255,255,.8)', border: '1px solid rgba(255,255,255,.3)' }} onClick={() => setPatient(null)}>← Chiqish</button>
      </div>

      <div className="portal-tabs">
        {[['book', '📅 Qabul belgilash'], ['history', '📄 Tarixi'], ['chat', '💬 Chat'], ['profile', '👤 Profil']].map(([id, label]) => (
          <button key={id} className={`patient-tab${activeTab === id ? ' active' : ''}`} onClick={() => { setActiveTab(id); if (id === 'history') loadHistory(); }}>{label}</button>
        ))}
      </div>

      <div className="portal-content">
        {activeTab === 'book' && (
          <>
            <div className="portal-card">
              <div className="portal-card-title">👨‍⚕️ Shifokorni tanlang</div>
              <div className="doc-pick-grid">
                {doctors.map(d => (
                  <div key={d.id} className={`doc-pick-card${selDoc?.id === d.id ? ' selected' : ''}`} onClick={() => pickDoc(d)}>
                    <div className="doc-pick-av">{d.photo ? <img src={d.photo} alt="" /> : `${d.firstName[0]}${d.lastName[0]}`}</div>
                    <div className="doc-pick-nm">{d.firstName} {d.lastName}</div>
                    <div className="doc-pick-sp">{d.spec}</div>
                    <div className="doc-pick-pr">{formatMoney(d.price)}</div>
                  </div>
                ))}
              </div>
            </div>

            {selDoc && (
              <div className="portal-card">
                <div className="portal-card-title">📅 Sanani tanlang</div>
                <div className="portal-form">
                  <input className="form-control" type="date" value={date} min={today()} onChange={onDateChange} />
                  <SlotPicker start={selDoc.start} end={selDoc.end} takenSlots={takenSlots} selected={slot} onSelect={setSlot} portalStyle />
                </div>
              </div>
            )}

            {slot && !bookResult && (
              <button className="btn btn-success btn-block btn-lg" onClick={book}>✓ Qabul belgilash</button>
            )}

            {bookResult && (
              <div className="queue-result">
                <div style={{ fontSize: '1rem', marginBottom: 10, opacity: .9 }}>✓ Qabul muvaffaqiyatli belgilandi!</div>
                <div className="queue-big-num">#{bookResult.queue}</div>
                <div className="queue-info-row">
                  <div className="queue-info-item"><strong>{bookResult.doctorName}</strong><span>Shifokor</span></div>
                  <div className="queue-info-item"><strong>{bookResult.time}</strong><span>Vaqt</span></div>
                  <div className="queue-info-item"><strong>{formatMoney(bookResult.price)}</strong><span>To'lov</span></div>
                  <div className="queue-info-item"><strong>{formatDate(bookResult.date)}</strong><span>Sana</span></div>
                </div>
                <button className="btn btn-sm" style={{ marginTop: 12, background: 'rgba(255,255,255,.2)', color: '#fff' }} onClick={() => { setBookResult(null); setSlot(null); }}>Yana belgilash</button>
              </div>
            )}
          </>
        )}

        {activeTab === 'history' && (
          <div className="portal-card">
            <div className="portal-card-title">📄 Qabullar tarixi</div>
            {history.length ? history.map(a => (
              <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, border: '1px solid rgba(255,255,255,.15)', borderRadius: 8, marginBottom: 8, background: 'rgba(255,255,255,.05)' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: '.88rem', color: '#fff' }}>{a.doctorName}</div>
                  <div style={{ fontSize: '.78rem', color: 'rgba(255,255,255,.7)' }}>{formatDate(a.date)} {a.time} · Navbat #{a.queue}</div>
                  {a.doneNote && <div style={{ fontSize: '.75rem', color: 'rgba(255,255,255,.6)', marginTop: 4 }}>Tashxis: {a.doneNote}</div>}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                  <StatusBadge status={a.status} />
                  {a.paid ? <Badge type="success" style={{fontSize:'.65rem'}}>To'langan</Badge> : <Badge type="warning">To'lanmagan</Badge>}
                  <span style={{ fontSize: '.78rem', fontWeight: 700, color: '#86efac' }}>{formatMoney(a.price)}</span>
                </div>
              </div>
            )) : <div style={{ color: 'rgba(255,255,255,.6)', textAlign: 'center', padding: 20 }}>Qabullar tarixi yo'q</div>}
          </div>
        )}

        {activeTab === 'chat' && (
          <div className="portal-card">
            <div className="portal-card-title">💬 Shifokor bilan chat</div>
            {!patient.id ? <div style={{ color: 'rgba(255,255,255,.7)', fontSize: '.85rem' }}>Chat uchun ro'yxatdan o'tgan bemor bo'lishingiz kerak.</div> : (
              <>
                {!chatDoc ? (
                  <div className="doc-pick-grid">
                    {doctors.map(d => (
                      <div key={d.id} className="doc-pick-card" onClick={() => openChat(d)}>
                        <div className="doc-pick-av">{d.photo ? <img src={d.photo} alt="" /> : `${d.firstName[0]}${d.lastName[0]}`}</div>
                        <div className="doc-pick-nm">{d.firstName} {d.lastName}</div>
                        <div className="doc-pick-sp">{d.spec}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                      <button className="btn btn-sm" style={{ color: 'rgba(255,255,255,.8)', border: '1px solid rgba(255,255,255,.3)' }} onClick={() => { setChatDoc(null); setChatKey(null); setMessages([]); }}>← Orqaga</button>
                      <strong style={{ color: '#fff' }}>{chatDoc.firstName} {chatDoc.lastName}</strong>
                    </div>
                    <div style={{ minHeight: 200, maxHeight: 300, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }} ref={msgsRef}>
                      {messages.length ? messages.map((m, i) => (
                        <div key={i} className={`msg ${m.sender === 'patient' ? 'sent' : 'recv'}`}>
                          <div className={`msg-bbl${m.isPrescription ? ' prescription' : ''}`}>{m.text}</div>
                          <div className="msg-meta">{m.sender === 'patient' ? 'Siz' : 'Shifokor'}</div>
                        </div>
                      )) : <div style={{ color: 'rgba(255,255,255,.5)', textAlign: 'center' }}>Xabar yo'q</div>}
                    </div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <input className="form-control" style={{ background: 'rgba(255,255,255,.1)', borderColor: 'rgba(255,255,255,.2)', color: '#fff' }} value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') sendChat(); }} placeholder="Xabar yozing..." />
                      <button className="btn" style={{ background: 'var(--primary)', color: '#fff' }} onClick={sendChat}>Yuborish</button>
                    </div>
                  </>
                )}
              </>
            )}
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="portal-card">
            <div className="portal-card-title">👤 Mening profilim</div>
            {patient.isGuest ? (
              <div style={{ textAlign: 'center', padding: 20 }}>
                <div style={{ fontSize: '3rem', marginBottom: 12 }}>👤</div>
                <div style={{ fontWeight: 700, fontSize: '1.1rem', color: '#fff', marginBottom: 6 }}>{patient.firstName}</div>
                <div style={{ background: 'rgba(255,165,0,.3)', padding: '4px 12px', borderRadius: 10, display: 'inline-block', color: '#fff', fontSize: '.8rem' }}>Mehmon foydalanuvchi</div>
                <p style={{ fontSize: '.82rem', color: 'rgba(255,255,255,.6)', marginTop: 12 }}>To'liq profil uchun registratorga murojaat qiling.</p>
              </div>
            ) : (
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: 14, background: 'rgba(255,255,255,.1)', borderRadius: 8, marginBottom: 14 }}>
                  <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'rgba(255,255,255,.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: '1.4rem' }}>{patient.firstName[0]}</div>
                  <div><div style={{ fontWeight: 800, fontSize: '1.1rem', color: '#fff' }}>{patient.firstName} {patient.lastName}</div><div style={{ fontSize: '.78rem', color: 'rgba(255,255,255,.7)' }}>{patient.phone || '—'}</div></div>
                </div>
                {[['Tug\'ilgan sana', formatDate(patient.dob)], ['Jins', patient.gender], ['Viloyat', patient.region], ['Tuman', patient.district]].map(([l, v]) => v ? (
                  <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid rgba(255,255,255,.1)', fontSize: '.85rem', color: 'rgba(255,255,255,.8)' }}>
                    <span>{l}</span><strong style={{ color: '#fff' }}>{v}</strong>
                  </div>
                ) : null)}
                {patient.history && <div style={{ marginTop: 10, background: 'rgba(255,165,0,.15)', border: '1px solid rgba(255,165,0,.3)', borderRadius: 8, padding: 10, fontSize: '.85rem', color: '#fff' }}><strong>Kasallik tarixi:</strong> {patient.history}</div>}
              </div>
            )}
          </div>
        )}
      </div>
      <NotifyContainer />
    </div>
  );
}
