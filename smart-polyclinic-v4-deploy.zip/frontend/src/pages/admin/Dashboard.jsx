import React, { useEffect, useState } from 'react';
import api from '../../api';
import { formatMoney, formatDate, today } from '../../utils/helpers';
import { StatusBadge } from '../../components/Badge';
import EmptyState from '../../components/EmptyState';

export default function AdminDashboard() {
  const [stats, setStats] = useState({ total: 0, done: 0, income: 0, todayCount: 0, todayIncome: 0, topDocs: [], recent: [] });
  const [doctorCount, setDoctorCount] = useState(0);
  const [patientCount, setPatientCount] = useState(0);

  useEffect(() => {
    api.get('/reports/stats').then(r => setStats(r.data));
    api.get('/doctors').then(r => setDoctorCount(r.data.length));
    api.get('/patients').then(r => setPatientCount(r.data.length));
  }, []);

  const max = stats.topDocs[0]?.[1] || 1;

  return (
    <div>
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'var(--primary-light)' }}>👨‍⚕️</div>
          <div><div className="stat-val">{doctorCount}</div><div className="stat-lbl">Shifokorlar</div></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'var(--success-light)' }}>👥</div>
          <div><div className="stat-val">{patientCount}</div><div className="stat-lbl">Bemorlar</div></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'var(--warning-light)' }}>📅</div>
          <div><div className="stat-val">{stats.todayCount}</div><div className="stat-lbl">Bugun qabullar</div></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'var(--info-light)' }}>💰</div>
          <div><div className="stat-val">{stats.todayIncome.toLocaleString('uz-UZ')}</div><div className="stat-lbl">Bugun daromad</div></div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16 }}>
        <div className="card">
          <div className="card-title">📅 Bugungi qabullar</div>
          {stats.recent.filter(a => a.date === today()).length ? (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Navbat</th><th>Bemor</th><th>Shifokor</th><th>Vaqt</th><th>Holat</th></tr></thead>
                <tbody>
                  {stats.recent.filter(a => a.date === today()).slice(0, 10).map(a => (
                    <tr key={a.id}>
                      <td><strong>#{a.queue}</strong></td>
                      <td>{a.patientName}</td>
                      <td>{a.doctorName}</td>
                      <td>{a.time}</td>
                      <td><StatusBadge status={a.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <EmptyState text="Bugun qabul yo'q" />}
        </div>

        <div className="card">
          <div className="card-title">🏆 Top shifokorlar</div>
          {stats.topDocs.length ? stats.topDocs.slice(0, 5).map(([name, cnt]) => (
            <div key={name} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.83rem', marginBottom: 4 }}>
                <span>{name.split(' ')[0]}</span><strong>{cnt} ta</strong>
              </div>
              <div className="prog-bar"><div className="prog-fill" style={{ width: `${(cnt / max * 100).toFixed(0)}%` }} /></div>
            </div>
          )) : <EmptyState text="Ma'lumot yo'q" />}

          <div style={{ marginTop: 16, borderTop: '1px solid var(--border)', paddingTop: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.82rem', marginBottom: 6 }}>
              <span>Jami qabullar:</span><strong>{stats.total}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.82rem', marginBottom: 6 }}>
              <span>Tugallangan:</span><strong style={{ color: 'var(--success)' }}>{stats.done}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.82rem' }}>
              <span>Jami daromad:</span><strong style={{ color: 'var(--success)' }}>{formatMoney(stats.income)}</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
