import React, { useEffect, useState } from 'react';
import api from '../../api';
import { formatMoney, formatDate } from '../../utils/helpers';
import { StatusBadge } from '../../components/Badge';
import EmptyState from '../../components/EmptyState';

export default function AdminReports() {
  const [stats, setStats] = useState({ total: 0, done: 0, income: 0, topDocs: [], recent: [], allApts: [] });
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [docFilter, setDocFilter] = useState('');
  const [doctors, setDoctors] = useState([]);

  const load = (params = {}) => api.get('/reports/stats', { params }).then(r => setStats(r.data));
  useEffect(() => { load(); api.get('/doctors').then(r => setDoctors(r.data)); }, []);

  const filter = () => { const p = {}; if (from) p.from = from; if (to) p.to = to; if (docFilter) p.doctorName = docFilter; load(p); };
  const reset = () => { setFrom(''); setTo(''); setDocFilter(''); load(); };

  const max = stats.topDocs[0]?.[1] || 1;
  const paid = stats.allApts?.filter(a => a.paid) || [];

  return (
    <div>
      <div className="page-header"><h1>📈 Hisobotlar</h1></div>

      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-title">Filtr</div>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div className="form-group" style={{ marginBottom: 0 }}><label className="form-label">Sanadan</label><input className="form-control" type="date" value={from} onChange={e => setFrom(e.target.value)} /></div>
          <div className="form-group" style={{ marginBottom: 0 }}><label className="form-label">Sanagacha</label><input className="form-control" type="date" value={to} onChange={e => setTo(e.target.value)} /></div>
          <div className="form-group" style={{ marginBottom: 0 }}><label className="form-label">Shifokor</label>
            <select className="form-control" value={docFilter} onChange={e => setDocFilter(e.target.value)}>
              <option value="">Barchasi</option>
              {doctors.map(d => <option key={d.id} value={`${d.firstName} ${d.lastName}`}>{d.firstName} {d.lastName}</option>)}
            </select>
          </div>
          <button className="btn btn-primary" onClick={filter}>Qidirish</button>
          <button className="btn btn-outline" onClick={reset}>Tozalash</button>
        </div>
      </div>

      <div className="stat-grid" style={{ marginBottom: 20 }}>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--primary-light)' }}>📅</div><div><div className="stat-val">{stats.total}</div><div className="stat-lbl">Jami qabullar</div></div></div>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--success-light)' }}>✅</div><div><div className="stat-val">{stats.done}</div><div className="stat-lbl">Tugallangan</div></div></div>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--info-light)' }}>💳</div><div><div className="stat-val">{paid.length}</div><div className="stat-lbl">To'langan</div></div></div>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--warning-light)' }}>💰</div><div><div className="stat-val">{stats.income.toLocaleString('uz-UZ')}</div><div className="stat-lbl">Daromad (so'm)</div></div></div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="card">
          <div className="card-title">Shifokorlar faoliyati</div>
          {stats.topDocs.length ? stats.topDocs.map(([name, cnt]) => (
            <div key={name} style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.83rem', marginBottom: 4 }}><span>{name}</span><strong>{cnt}</strong></div>
              <div className="prog-bar"><div className="prog-fill" style={{ width: `${(cnt / max * 100).toFixed(0)}%` }} /></div>
            </div>
          )) : <EmptyState text="Ma'lumot yo'q" />}
        </div>
        <div className="card">
          <div className="card-title">So'nggi to'lovlar</div>
          <div className="table-wrap">
            {paid.length ? <table><thead><tr><th>Bemor</th><th>Shifokor</th><th>Sana</th><th>Summa</th></tr></thead><tbody>
              {paid.sort((a, b) => b.date > a.date ? 1 : -1).slice(0, 10).map(a => (
                <tr key={a.id}><td>{a.patientName}</td><td>{a.doctorName}</td><td>{formatDate(a.date)}</td><td style={{ fontWeight: 700, color: 'var(--success)' }}>{formatMoney(a.price)}</td></tr>
              ))}
            </tbody></table> : <EmptyState text="To'lovlar yo'q" />}
          </div>
        </div>
      </div>
    </div>
  );
}
