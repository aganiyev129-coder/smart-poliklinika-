import React, { useEffect, useState } from 'react';
import api from '../../api';
import Modal from '../../components/Modal';
import EmptyState from '../../components/EmptyState';
import PhotoUpload from '../../components/PhotoUpload';
import { notify } from '../../components/Notify';
import { formatMoney } from '../../utils/helpers';
import { SPECS } from '../../utils/constants';

const empty = { firstName: '', lastName: '', spec: 'Terapevt', start: '08:00', end: '17:00', price: '', phone: '', exp: '', photo: '' };

export default function AdminDoctors() {
  const [doctors, setDoctors] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(empty);
  const [editId, setEditId] = useState(null);
  const [search, setSearch] = useState('');
  const [credModal, setCredModal] = useState(false);
  const [creds, setCreds] = useState(null);

  const load = () => api.get('/doctors').then(r => { setDoctors(r.data); setFiltered(r.data); });
  useEffect(() => { load(); }, []);

  useEffect(() => {
    const q = search.toLowerCase();
    setFiltered(doctors.filter(d => `${d.firstName} ${d.lastName} ${d.spec}`.toLowerCase().includes(q)));
  }, [search, doctors]);

  const openAdd = () => { setForm(empty); setEditId(null); setModal(true); };
  const openEdit = d => { setForm({ ...d, price: d.price || '', exp: d.exp || '' }); setEditId(d.id); setModal(true); };

  const save = async () => {
    if (!form.firstName || !form.lastName || !form.price) { notify("Majburiy maydonlarni to'ldiring!", 'warning'); return; }
    try {
      if (editId) {
        await api.put(`/doctors/${editId}`, form);
        notify('Tahrirlandi!', 'success');
      } else {
        const r = await api.post('/doctors', form);
        setCreds({ username: r.data.generatedUsername, password: r.data.generatedPassword, name: `${form.firstName} ${form.lastName}` });
        setCredModal(true);
      }
      setModal(false); load();
    } catch (e) { notify(e.response?.data?.error || 'Xatolik', 'danger'); }
  };

  const del = async id => {
    if (!confirm("Shifokorni o'chirmoqchimisiz?")) return;
    await api.delete(`/doctors/${id}`);
    notify("O'chirildi", 'danger'); load();
  };

  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <div>
      <div className="page-header">
        <h1>👨‍⚕️ Shifokorlar</h1>
        <button className="btn btn-primary" onClick={openAdd}>+ Shifokor qo'shish</button>
      </div>

      <div className="doc-search">
        <input className="form-control" placeholder="Qidirish..." value={search} onChange={e => setSearch(e.target.value)} style={{ maxWidth: 300 }} />
      </div>

      <div className="doc-grid">
        {filtered.length ? filtered.map(d => (
          <div className="doc-card" key={d.id}>
            <div className="doc-av">{d.photo ? <img src={d.photo} alt="" /> : `${d.firstName[0]}${d.lastName[0]}`}</div>
            <div className="doc-nm">{d.firstName} {d.lastName}</div>
            <div className="doc-sp">{d.spec}</div>
            <div className="doc-pr">{formatMoney(d.price)}</div>
            <div className="doc-meta">⏰ {d.start} – {d.end}</div>
            {d.exp > 0 && <div className="doc-meta">Tajriba: {d.exp} yil</div>}
            <div className="doc-acts">
              <button className="btn btn-outline btn-sm" onClick={() => openEdit(d)}>✏️</button>
              <button className="btn btn-danger btn-sm" onClick={() => del(d.id)}>🗑️</button>
            </div>
          </div>
        )) : <div style={{ gridColumn: '1/-1' }}><EmptyState text="Shifokorlar yo'q" /></div>}
      </div>

      <Modal open={credModal} onClose={() => setCredModal(false)} title="✅ Shifokor qo'shildi — Login ma'lumotlari"
        footer={<button className="btn btn-primary" onClick={() => setCredModal(false)}>Tushunarli</button>}>
        {creds && (
          <div style={{ textAlign: 'center' }}>
            <p style={{ marginBottom: 16, color: 'var(--text2)' }}><strong>{creds.name}</strong> uchun tizimga kirish ma'lumotlari:</p>
            <div style={{ background: 'var(--bg2)', borderRadius: 'var(--radius)', padding: '16px 24px', fontSize: '1rem', lineHeight: 2 }}>
              <div>👤 Login: <strong style={{ color: 'var(--primary)' }}>{creds.username}</strong></div>
              <div>🔑 Parol: <strong style={{ color: 'var(--primary)' }}>{creds.password}</strong></div>
            </div>
            <p style={{ marginTop: 12, fontSize: '.8rem', color: 'var(--text3)' }}>Ushbu ma'lumotlarni shifokorga bering. Parolni keyinchalik o'zgartirish mumkin.</p>
          </div>
        )}
      </Modal>

      <Modal open={modal} onClose={() => setModal(false)} title={editId ? 'Shifokorni tahrirlash' : "Shifokor qo'shish"}
        footer={<>
          <button className="btn btn-outline" onClick={() => setModal(false)}>Bekor</button>
          <button className="btn btn-primary" onClick={save}>Saqlash</button>
        </>}>
        <PhotoUpload value={form.photo} onChange={v => setForm(p => ({ ...p, photo: v }))} />
        <div className="form-row">
          <div className="form-group"><label className="form-label">Ism <span className="req">*</span></label><input className="form-control" value={form.firstName} onChange={f('firstName')} /></div>
          <div className="form-group"><label className="form-label">Familiya <span className="req">*</span></label><input className="form-control" value={form.lastName} onChange={f('lastName')} /></div>
        </div>
        <div className="form-group"><label className="form-label">Mutaxassislik</label>
          <select className="form-control" value={form.spec} onChange={f('spec')}>
            {SPECS.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div className="form-row">
          <div className="form-group"><label className="form-label">Ish boshlanish</label><input className="form-control" type="time" value={form.start} onChange={f('start')} /></div>
          <div className="form-group"><label className="form-label">Ish tugash</label><input className="form-control" type="time" value={form.end} onChange={f('end')} /></div>
        </div>
        <div className="form-row">
          <div className="form-group"><label className="form-label">Narx (so'm) <span className="req">*</span></label><input className="form-control" type="number" value={form.price} onChange={f('price')} /></div>
          <div className="form-group"><label className="form-label">Tajriba (yil)</label><input className="form-control" type="number" value={form.exp} onChange={f('exp')} /></div>
        </div>
        <div className="form-group"><label className="form-label">Telefon</label><input className="form-control" value={form.phone} onChange={f('phone')} /></div>
      </Modal>
    </div>
  );
}
