import React, { useEffect, useState } from 'react';
import api from '../../api';
import EmptyState from '../../components/EmptyState';
import { notify } from '../../components/Notify';

const TYPE_BG = { success: 'var(--success-light)', danger: 'var(--danger-light)', warning: 'var(--warning-light)', info: 'var(--info-light)' };

export default function AdminLogs() {
  const [logs, setLogs] = useState([]);

  const load = () => api.get('/logs').then(r => setLogs(r.data));
  useEffect(() => { load(); }, []);

  const clearAll = async () => {
    if (!confirm('Jurnalni tozalamoqchimisiz?')) return;
    await api.delete('/logs');
    notify('Jurnal tozalandi', 'success');
    load();
  };

  return (
    <div>
      <div className="page-header">
        <h1>📋 Faoliyat jurnali</h1>
        <button className="btn btn-danger btn-sm" onClick={clearAll}>🗑️ Tozalash</button>
      </div>

      <div className="card">
        {logs.length ? logs.map(l => (
          <div key={l.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 0', borderBottom: '1px solid var(--border)' }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: TYPE_BG[l.type] || 'var(--bg3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '.85rem', flexShrink: 0 }}>{l.icon}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '.85rem', fontWeight: 500 }}>{l.action}</div>
              <div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>{l.user} · {new Date(l.time).toLocaleString('uz-UZ')}</div>
            </div>
          </div>
        )) : <EmptyState text="Jurnal bo'sh" />}
      </div>
    </div>
  );
}
