import React, { useEffect, useState } from 'react';
import api from '../../api';
import EmptyState from '../../components/EmptyState';
import Modal from '../../components/Modal';
import { StatusBadge } from '../../components/Badge';
import { formatDate } from '../../utils/helpers';

export default function AdminPatients() {
  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState('');
  const [histModal, setHistModal] = useState(false);
  const [histData, setHistData] = useState(null);

  const load = () => api.get('/patients').then(r => setPatients(r.data));
  useEffect(() => { load(); }, []);

  const filtered = patients.filter(p =>
    `${p.firstName} ${p.lastName} ${p.phone}`.toLowerCase().includes(search.toLowerCase())
  );

  const viewHistory = async p => {
    const apts = await api.get('/appointments', { params: { patientId: p.id } });
    setHistData({ patient: p, apts: apts.data });
    setHistModal(true);
  };

  return (
    <div>
      <div className="page-header">
        <h1>👥 Bemorlar</h1>
        <input className="form-control" placeholder="Qidirish..." value={search} onChange={e => setSearch(e.target.value)} style={{ maxWidth: 280 }} />
      </div>

      <div className="table-wrap">
        <table>
          <thead><tr><th>#</th><th>Ism</th><th>Telefon</th><th>Viloyat</th><th>Tug'ilgan</th><th>Amal</th></tr></thead>
          <tbody>
            {filtered.length ? filtered.map((p, i) => (
              <tr key={p.id}>
                <td>{i + 1}</td>
                <td><div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><div className="av-sm">{p.firstName[0]}</div><strong>{p.firstName} {p.lastName}</strong></div></td>
                <td>{p.phone || '—'}</td>
                <td>{p.region || '—'}</td>
                <td>{formatDate(p.dob)}</td>
                <td><button className="btn btn-info btn-sm" onClick={() => viewHistory(p)}>📄 Tarix</button></td>
              </tr>
            )) : <tr><td colSpan={6}><EmptyState text="Bemorlar yo'q" /></td></tr>}
          </tbody>
        </table>
      </div>

      <Modal open={histModal} onClose={() => setHistModal(false)} title={histData ? `${histData.patient.firstName} ${histData.patient.lastName} — Tarix` : ''} wide
        footer={<button className="btn btn-outline" onClick={() => setHistModal(false)}>Yopish</button>}>
        {histData && (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
              <div><div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>Telefon</div><strong>{histData.patient.phone || '—'}</strong></div>
              <div><div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>Viloyat</div><strong>{histData.patient.region || '—'}</strong></div>
              <div><div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>Tug'ilgan</div><strong>{formatDate(histData.patient.dob)}</strong></div>
              <div><div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>Jins</div><strong>{histData.patient.gender || '—'}</strong></div>
            </div>
            {histData.patient.history && <div style={{ background: 'var(--warning-light)', border: '1px solid var(--warning)', borderRadius: 8, padding: 10, marginBottom: 14, fontSize: '.85rem' }}><strong>Kasallik tarixi:</strong> {histData.patient.history}</div>}
            <div style={{ fontWeight: 700, marginBottom: 10 }}>Qabullar ({histData.apts.length} ta):</div>
            {histData.apts.length ? histData.apts.map(a => (
              <div key={a.id} style={{ border: '1px solid var(--border)', borderRadius: 8, padding: 10, marginBottom: 7 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><strong>{a.doctorName}</strong><StatusBadge status={a.status} /></div>
                <div style={{ fontSize: '.78rem', color: 'var(--text2)', marginTop: 3 }}>{formatDate(a.date)} {a.time} · #{a.queue}</div>
                {a.doneNote && <div style={{ fontSize: '.78rem', color: 'var(--text3)', marginTop: 4, padding: 6, background: 'var(--bg3)', borderRadius: 5 }}>{a.doneNote}</div>}
              </div>
            )) : <EmptyState text="Qabul yo'q" />}
          </>
        )}
      </Modal>
    </div>
  );
}
