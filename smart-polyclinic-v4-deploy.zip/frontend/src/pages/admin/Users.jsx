import React, { useEffect, useState } from 'react';
import api from '../../api';
import Modal from '../../components/Modal';
import { Badge } from '../../components/Badge';
import { notify } from '../../components/Notify';
import EmptyState from '../../components/EmptyState';
import PhotoUpload from '../../components/PhotoUpload';
import { useAuth } from '../../context/AuthContext';

const empty = { firstName: '', lastName: '', username: '', password: '', role: 'registrar', photo: '' };

export default function AdminUsers() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(empty);
  const [editId, setEditId] = useState(null);

  const load = () => api.get('/users').then(r => setUsers(r.data));
  useEffect(() => { load(); }, []);

  const openAdd = () => { setForm(empty); setEditId(null); setModal(true); };
  const openEdit = u => { setForm({ ...u, password: '' }); setEditId(u.id); setModal(true); };

  const save = async () => {
    if (!form.firstName || !form.username || (!editId && !form.password)) { notify("Majburiy maydonlarni to'ldiring!", 'warning'); return; }
    try {
      const payload = { ...form };
      if (editId && !payload.password) delete payload.password;
      if (editId) { await api.put(`/users/${editId}`, payload); notify('Tahrirlandi!', 'success'); }
      else { await api.post('/users', payload); notify("Qo'shildi!", 'success'); }
      setModal(false); load();
    } catch (e) { notify(e.response?.data?.error || 'Xatolik', 'danger'); }
  };

  const del = async id => {
    if (!confirm("O'chirmoqchimisiz?")) return;
    try { await api.delete(`/users/${id}`); notify("O'chirildi", 'danger'); load(); }
    catch (e) { notify(e.response?.data?.error || 'Xatolik', 'danger'); }
  };

  const ROLE_LABELS = { superadmin: 'Super Admin', registrar: 'Registrator', doctor: 'Shifokor' };
  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <div>
      <div className="page-header">
        <h1>🔑 Foydalanuvchilar</h1>
        <button className="btn btn-primary" onClick={openAdd}>+ Foydalanuvchi qo'shish</button>
      </div>

      <div className="table-wrap">
        <table>
          <thead><tr><th>#</th><th>Ism</th><th>Username</th><th>Rol</th><th>Holat</th><th>Amal</th></tr></thead>
          <tbody>
            {users.length ? users.map((u, i) => (
              <tr key={u.id}>
                <td>{i + 1}</td>
                <td><div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><div className="av-sm">{u.photo ? <img src={u.photo} alt="" /> : (u.firstName || 'U')[0]}</div><strong>{u.firstName} {u.lastName}</strong></div></td>
                <td><code>{u.username}</code></td>
                <td><Badge type="primary">{ROLE_LABELS[u.role] || u.role}</Badge></td>
                <td><Badge type={u.active ? 'success' : 'danger'}>{u.active ? 'Faol' : 'Nofaol'}</Badge></td>
                <td>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button className="btn btn-outline btn-sm" onClick={() => openEdit(u)}>✏️</button>
                    <button className="btn btn-danger btn-sm" onClick={() => del(u.id)} disabled={u.id === currentUser?.id}>🗑️</button>
                  </div>
                </td>
              </tr>
            )) : <tr><td colSpan={6}><EmptyState text="Foydalanuvchilar yo'q" /></td></tr>}
          </tbody>
        </table>
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title={editId ? 'Foydalanuvchini tahrirlash' : "Foydalanuvchi qo'shish"}
        footer={<><button className="btn btn-outline" onClick={() => setModal(false)}>Bekor</button><button className="btn btn-primary" onClick={save}>Saqlash</button></>}>
        <PhotoUpload value={form.photo} onChange={v => setForm(p => ({ ...p, photo: v }))} />
        <div className="form-row">
          <div className="form-group"><label className="form-label">Ism <span className="req">*</span></label><input className="form-control" value={form.firstName} onChange={f('firstName')} /></div>
          <div className="form-group"><label className="form-label">Familiya</label><input className="form-control" value={form.lastName} onChange={f('lastName')} /></div>
        </div>
        <div className="form-group"><label className="form-label">Username <span className="req">*</span></label><input className="form-control" value={form.username} onChange={f('username')} /></div>
        <div className="form-group"><label className="form-label">Parol {editId ? '' : <span className="req">*</span>}</label><input className="form-control" type="password" value={form.password} onChange={f('password')} placeholder={editId ? "Bo'sh qoldiring — o'zgarmaydi" : ''} /></div>
        <div className="form-group"><label className="form-label">Rol</label>
          <select className="form-control" value={form.role} onChange={f('role')}>
            <option value="superadmin">Super Admin</option>
            <option value="registrar">Registrator</option>
            <option value="doctor">Shifokor</option>
          </select>
        </div>
      </Modal>
    </div>
  );
}
