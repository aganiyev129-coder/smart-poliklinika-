import React, { useEffect, useState } from 'react';
import api from '../../api';
import { notify } from '../../components/Notify';

export default function AdminSettings() {
  const [form, setForm] = useState({ name: '', addr: '', phone: '' });
  const [theme, setTheme] = useState(document.documentElement.getAttribute('data-theme') || 'light');

  useEffect(() => {
    api.get('/settings').then(r => setForm({ name: r.data.name || '', addr: r.data.addr || '', phone: r.data.phone || '' }));
  }, []);

  const save = async () => {
    await api.put('/settings', form);
    notify('Saqlandi!', 'success');
  };

  const exportData = async () => {
    const [docs, pats, apts, users, logs] = await Promise.all([
      api.get('/doctors'), api.get('/patients'), api.get('/appointments'),
      api.get('/users'), api.get('/logs')
    ]);
    const data = { doctors: docs.data, patients: pats.data, appointments: apts.data, users: users.data, logs: logs.data, date: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `poliklinika_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    notify('Yuklab olindi!', 'success');
  };

  const toggleTheme = () => {
    const t = theme === 'dark' ? 'light' : 'dark';
    setTheme(t);
    document.documentElement.setAttribute('data-theme', t);
    localStorage.setItem('theme', t);
  };

  useEffect(() => {
    const saved = localStorage.getItem('theme') || 'light';
    setTheme(saved);
    document.documentElement.setAttribute('data-theme', saved);
  }, []);

  return (
    <div style={{ maxWidth: 560 }}>
      <div className="page-header"><h1>⚙️ Sozlamalar</h1></div>

      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-title">🏥 Klinika ma'lumotlari</div>
        <div className="form-group"><label className="form-label">Klinika nomi</label><input className="form-control" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
        <div className="form-group"><label className="form-label">Manzil</label><input className="form-control" value={form.addr} onChange={e => setForm(p => ({ ...p, addr: e.target.value }))} /></div>
        <div className="form-group"><label className="form-label">Telefon</label><input className="form-control" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} /></div>
        <button className="btn btn-primary" onClick={save}>💾 Saqlash</button>
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-title">🎨 Ko'rinish</div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span>Qorong'i rejim</span>
          <button className="btn btn-outline btn-sm" onClick={toggleTheme}>
            {theme === 'dark' ? "☀️ Yorug'" : "🌙 Qorong'i"}
          </button>
        </div>
      </div>

      <div className="card">
        <div className="card-title">📦 Ma'lumotlar</div>
        <p style={{ fontSize: '.85rem', color: 'var(--text2)', marginBottom: 14 }}>Barcha ma'lumotlarni JSON formatida yuklab olish</p>
        <button className="btn btn-outline" onClick={exportData}>⬇️ Eksport qilish</button>
      </div>
    </div>
  );
}
