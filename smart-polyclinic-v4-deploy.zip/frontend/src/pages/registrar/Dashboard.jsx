import React, { useEffect, useState } from 'react';
import api from '../../api';
import { today, formatMoney } from '../../utils/helpers';
import { StatusBadge } from '../../components/Badge';
import EmptyState from '../../components/EmptyState';

export default function RegDashboard() {
  const [stats, setStats] = useState({ patCount: 0, todayApts: [], pending: 0, income: 0 });

  useEffect(() => {
    Promise.all([
      api.get('/patients'),
      api.get('/appointments', { params: { date: today() } })
    ]).then(([pats, apts]) => {
      const list = apts.data;
      setStats({
        patCount: pats.data.length,
        todayApts: list,
        pending: list.filter(a => a.status === 'pending').length,
        income: list.filter(a => a.paid).reduce((s, a) => s + (a.price || 0), 0)
      });
    });
  }, []);

  return (
    <div>
      <div className="stat-grid">
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--primary-light)' }}>👥</div><div><div className="stat-val">{stats.patCount}</div><div className="stat-lbl">Jami bemorlar</div></div></div>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--warning-light)' }}>📅</div><div><div className="stat-val">{stats.todayApts.length}</div><div className="stat-lbl">Bugun qabullar</div></div></div>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--info-light)' }}>⏳</div><div><div className="stat-val">{stats.pending}</div><div className="stat-lbl">Kutilmoqda</div></div></div>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--success-light)' }}>💰</div><div><div className="stat-val">{stats.income.toLocaleString()}</div><div className="stat-lbl">Bugun daromad</div></div></div>
      </div>

      <div className="card">
        <div className="card-title">📅 Bugungi qabullar</div>
        {stats.todayApts.length ? (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Navbat</th><th>Bemor</th><th>Shifokor</th><th>Vaqt</th><th>Holat</th></tr></thead>
              <tbody>
                {stats.todayApts.map(a => (
                  <tr key={a.id}>
                    <td><strong>#{a.queue}</strong></td>
                    <td>{a.patientName}</td>
                    <td>{a.doctorName}</td>
                    <td>{a.time}</td>
                    <td><StatusBadge status={a.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <EmptyState text="Bugun qabul yo'q" />}
      </div>
    </div>
  );
}
