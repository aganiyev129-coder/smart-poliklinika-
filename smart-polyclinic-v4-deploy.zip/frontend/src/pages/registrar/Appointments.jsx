import React, { useEffect, useState } from 'react';
import api from '../../api';
import Modal from '../../components/Modal';
import EmptyState from '../../components/EmptyState';
import SlotPicker from '../../components/SlotPicker';
import { StatusBadge, Badge } from '../../components/Badge';
import { notify } from '../../components/Notify';
import { formatDate, formatMoney, today } from '../../utils/helpers';

export default function RegAppointments() {
  const [apts, setApts] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [filter, setFilter] = useState('all');
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ patientId: '', doctorId: '', date: today(), note: '' });
  const [takenSlots, setTakenSlots] = useState([]);
  const [slot, setSlot] = useState(null);
  const [selDoc, setSelDoc] = useState(null);
  const [queuePreview, setQueuePreview] = useState(null);

  const load = () => api.get('/appointments').then(r => setApts(r.data));
  useEffect(() => {
    load();
    api.get('/patients').then(r => setPatients(r.data));
    api.get('/doctors').then(r => setDoctors(r.data));
  }, []);

  const filtered = apts.filter(a => {
    if (filter === 'today') return a.date === today();
    if (filter === 'pending') return a.status === 'pending';
    if (filter === 'done') return a.status === 'done';
    return true;
  }).sort((a, b) => b.date > a.date ? 1 : a.time > b.time ? 1 : -1);

  const loadSlots = async (docId, date) => {
    if (!docId || !date) return;
    const r = await api.get('/appointments', { params: { doctorId: docId, date } });
    setTakenSlots(r.data.filter(a => a.status !== 'cancelled').map(a => a.time));
  };

  const onDocChange = async e => {
    const id = e.target.value;
    setForm(p => ({ ...p, doctorId: id }));
    setSlot(null); setQueuePreview(null);
    const doc = doctors.find(d => d.id === parseInt(id));
    setSelDoc(doc || null);
    if (id && form.date) loadSlots(id, form.date);
  };

  const onDateChange = e => {
    setForm(p => ({ ...p, date: e.target.value }));
    setSlot(null); setQueuePreview(null);
    if (form.doctorId && e.target.value) loadSlots(form.doctorId, e.target.value);
  };

  const pickSlot = async t => {
    setSlot(t);
    const same = apts.filter(a => a.doctorId === parseInt(form.doctorId) && a.date === form.date && a.status !== 'cancelled');
    const ahead = same.filter(a => a.time < t).length;
    setQueuePreview({ num: same.length + 1, ahead });
  };

  const openModal = () => { setForm({ patientId: '', doctorId: '', date: today(), note: '' }); setSlot(null); setSelDoc(null); setTakenSlots([]); setQueuePreview(null); setModal(true); };

  const save = async () => {
    const pat = patients.find(p => p.id === parseInt(form.patientId));
    const doc = doctors.find(d => d.id === parseInt(form.doctorId));
    if (!pat || !doc || !form.date || !slot) { notify("Barcha maydonlarni to'ldiring!", 'warning'); return; }
    try {
      await api.post('/appointments', { patientId: pat.id, patientName: `${pat.firstName} ${pat.lastName}`, doctorId: doc.id, doctorName: `${doc.firstName} ${doc.lastName}`, date: form.date, time: slot, price: doc.price, note: form.note });
      notify(`Navbat #${queuePreview?.num} belgilandi!`, 'success');
      setModal(false); load();
    } catch (e) { notify(e.response?.data?.error || 'Xatolik', 'danger'); }
  };

  const markDone = async id => { await api.patch(`/appointments/${id}`, { status: 'done' }); notify('Tugallandi!', 'success'); load(); };
  const markPaid = async id => { await api.patch(`/appointments/${id}`, { paid: true }); notify("To'lov belgilandi!", 'success'); load(); };
  const cancel = async id => { if (!confirm('Bekor qilmoqchimisiz?')) return; await api.patch(`/appointments/${id}`, { status: 'cancelled' }); notify('Bekor qilindi', 'warning'); load(); };

  return (
    <div>
      <div className="page-header">
        <h1>📅 Qabullar</h1>
        <button className="btn btn-primary" onClick={openModal}>+ Yangi qabul</button>
      </div>

      <div className="tab-row">
        {[['all', 'Barchasi'], ['today', 'Bugun'], ['pending', 'Kutilmoqda'], ['done', 'Tugallangan']].map(([v, l]) => (
          <button key={v} className={`tab-btn${filter === v ? ' active' : ''}`} onClick={() => setFilter(v)}>{l}</button>
        ))}
      </div>

      <div className="table-wrap">
        <table>
          <thead><tr><th>Navbat</th><th>Bemor</th><th>Shifokor</th><th>Sana/Vaqt</th><th>Holat</th><th>To'lov</th><th>Amal</th></tr></thead>
          <tbody>
            {filtered.length ? filtered.map(a => (
              <tr key={a.id}>
                <td><strong>#{a.queue}</strong></td>
                <td>{a.patientName}</td>
                <td>{a.doctorName}</td>
                <td>{formatDate(a.date)} {a.time}</td>
                <td><StatusBadge status={a.status} /></td>
                <td>{a.paid ? <Badge type="success">To'langan</Badge> : <Badge type="warning">To'lanmagan</Badge>}</td>
                <td>
                  <div style={{ display: 'flex', gap: 3 }}>
                    {a.status === 'pending' && <button className="btn btn-success btn-sm" onClick={() => markDone(a.id)}>✓</button>}
                    {!a.paid && <button className="btn btn-info btn-sm" onClick={() => markPaid(a.id)}>💳</button>}
                    {a.status !== 'cancelled' && <button className="btn btn-danger btn-sm" onClick={() => cancel(a.id)}>✕</button>}
                  </div>
                </td>
              </tr>
            )) : <tr><td colSpan={7}><EmptyState text="Qabullar yo'q" /></td></tr>}
          </tbody>
        </table>
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title="Yangi qabul belgilash"
        footer={<><button className="btn btn-outline" onClick={() => setModal(false)}>Bekor</button><button className="btn btn-primary" onClick={save}>Saqlash</button></>}>
        <div className="form-group"><label className="form-label">Bemor <span className="req">*</span></label>
          <select className="form-control" value={form.patientId} onChange={e => setForm(p => ({ ...p, patientId: e.target.value }))}>
            <option value="">— Bemor tanlang —</option>
            {patients.map(p => <option key={p.id} value={p.id}>{p.firstName} {p.lastName}</option>)}
          </select>
        </div>
        <div className="form-group"><label className="form-label">Shifokor <span className="req">*</span></label>
          <select className="form-control" value={form.doctorId} onChange={onDocChange}>
            <option value="">— Shifokor tanlang —</option>
            {doctors.map(d => <option key={d.id} value={d.id}>{d.firstName} {d.lastName} ({d.spec})</option>)}
          </select>
        </div>
        <div className="form-group"><label className="form-label">Sana <span className="req">*</span></label><input className="form-control" type="date" value={form.date} onChange={onDateChange} /></div>
        {selDoc && <SlotPicker start={selDoc.start} end={selDoc.end} takenSlots={takenSlots} selected={slot} onSelect={pickSlot} />}
        {queuePreview && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, background: 'var(--bg3)', borderRadius: 'var(--radius-xs)', padding: 12, marginTop: 12 }}>
            <div className="queue-banner"><div className="queue-num">#{queuePreview.num}</div><div className="queue-lbl">Navbat</div></div>
            <div><div style={{ fontSize: '.82rem', color: 'var(--text2)' }}>Oldingizda:</div><div style={{ fontWeight: 700, fontSize: '1.1rem' }}>{queuePreview.ahead} nafar</div></div>
          </div>
        )}
        <div className="form-group" style={{ marginTop: 12 }}><label className="form-label">Izoh</label><textarea className="form-control" value={form.note} onChange={e => setForm(p => ({ ...p, note: e.target.value }))} rows={2} /></div>
      </Modal>
    </div>
  );
}
