import React, { useEffect, useState, useRef } from 'react';
import api from '../../api';
import { formatDate, formatMoney } from '../../utils/helpers';
import { notify } from '../../components/Notify';

export default function RegPayment() {
  const [apts, setApts] = useState([]);
  const [selId, setSelId] = useState('');
  const [apt, setApt] = useState(null);
  const [clinic, setClinic] = useState({});
  const [receiptHtml, setReceiptHtml] = useState('');
  const printRef = useRef();

  const load = () => api.get('/appointments').then(r => setApts(r.data.filter(a => !a.paid && a.status !== 'cancelled')));
  useEffect(() => { load(); api.get('/settings').then(r => setClinic(r.data)); }, []);

  const onSelect = e => {
    const id = parseInt(e.target.value);
    setSelId(e.target.value);
    setApt(apts.find(a => a.id === id) || null);
    setReceiptHtml('');
  };

  const showQR = (type) => {
    const names = { payme: 'Payme', click: 'Click' };
    setReceiptHtml(`<div style="text-align:center;padding:20px;">
      <div style="font-size:3rem;margin-bottom:8px;">${type === 'payme' ? '🟦' : '🟩'} ${names[type]}</div>
      <div style="border:2px dashed #ccc;border-radius:8px;padding:20px;display:inline-block;margin-bottom:12px;font-size:.85rem;">
        QR kod: ${apt.patientName} — ${formatMoney(apt.price)}
      </div>
      <div style="font-size:.8rem;color:#666;">${names[type]} ilovangizni oching va QR kodni skaner qiling</div>
    </div>`);
  };

  const printReceipt = async () => {
    const html = `<div class="receipt-paper">
      <div class="receipt-hdr"><div style="font-size:1.4rem">🏥</div><div style="font-weight:700;">${clinic.name || 'Aqlli Poliklinika'}</div>${clinic.addr ? `<div style="font-size:.75rem">${clinic.addr}</div>` : ''}${clinic.phone ? `<div style="font-size:.75rem">${clinic.phone}</div>` : ''}</div>
      <hr class="receipt-div">
      <div class="receipt-row"><span>Sana:</span><span>${formatDate(apt.date)}</span></div>
      <div class="receipt-row"><span>Vaqt:</span><span>${apt.time}</span></div>
      <div class="receipt-row"><span>Bemor:</span><span>${apt.patientName}</span></div>
      <div class="receipt-row"><span>Shifokor:</span><span>${apt.doctorName}</span></div>
      <div class="receipt-row"><span>Navbat:</span><span>#${apt.queue}</span></div>
      <hr class="receipt-div">
      <div class="receipt-row receipt-total"><span>JAMI:</span><span>${formatMoney(apt.price)}</span></div>
      <hr class="receipt-div">
      <div style="text-align:center;font-size:.72rem;margin-top:8px;">Xizmatdan foydalanganingiz uchun rahmat!</div>
      <div style="text-align:center;font-size:.68rem;color:#888;">${new Date().toLocaleString('uz-UZ')}</div>
    </div>`;
    setReceiptHtml(html);
    await api.patch(`/appointments/${apt.id}`, { paid: true });
    notify("Chek tayyor! Ctrl+P bosib chiqaring", 'success');
    load();
    setTimeout(() => window.print(), 400);
  };

  return (
    <div>
      <div className="page-header"><h1>💳 To'lov va cheklar</h1></div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="card">
          <div className="card-title">Qabulni tanlang</div>
          <div className="form-group">
            <label className="form-label">To'lanmagan qabullar</label>
            <select className="form-control" value={selId} onChange={onSelect}>
              <option value="">— Tanlang —</option>
              {apts.map(a => <option key={a.id} value={a.id}>{a.patientName} → {a.doctorName} ({formatDate(a.date)} {a.time})</option>)}
            </select>
          </div>

          {apt && (
            <div style={{ background: 'var(--bg3)', borderRadius: 'var(--radius-xs)', padding: 12, marginTop: 10 }}>
              {[['Bemor', apt.patientName], ['Shifokor', apt.doctorName], ['Sana/Vaqt', `${formatDate(apt.date)} ${apt.time}`], ['Navbat', `#${apt.queue}`]].map(([l, v]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: '.85rem' }}><span>{l}:</span><strong>{v}</strong></div>
              ))}
              <hr style={{ margin: '8px 0', borderColor: 'var(--border)' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '1rem' }}><span>Jami:</span><strong style={{ color: 'var(--success)' }}>{formatMoney(apt.price)}</strong></div>
            </div>
          )}

          {apt && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 10 }}>
              <button className="btn btn-success btn-sm" onClick={() => showQR('payme')}>Payme QR</button>
              <button className="btn btn-info btn-sm" onClick={() => showQR('click')}>Click QR</button>
              <button className="btn btn-primary" onClick={printReceipt} style={{ gridColumn: '1/-1' }}>🖨️ Chek chiqarish</button>
            </div>
          )}
        </div>

        <div className="card print-target" ref={printRef}>
          <div className="card-title">Chek / QR</div>
          {receiptHtml ? (
            <div dangerouslySetInnerHTML={{ __html: receiptHtml }} />
          ) : (
            <div style={{ textAlign: 'center', padding: '32px 20px', color: 'var(--text3)' }}>
              <div style={{ fontSize: '3rem', marginBottom: 8 }}>🧾</div>
              <div>To'lov usulini tanlang</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
