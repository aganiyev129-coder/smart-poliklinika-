import React, { useEffect, useState } from 'react';
import api from '../../api';
import Modal from '../../components/Modal';
import EmptyState from '../../components/EmptyState';
import { StatusBadge } from '../../components/Badge';
import { notify } from '../../components/Notify';
import { formatDate } from '../../utils/helpers';
import { UZ_REGIONS } from '../../utils/constants';

const empty = { firstName: '', lastName: '', dob: '', gender: 'erkak', phone: '', region: '', district: '', addr: '', history: '' };

export default function RegPatients() {
  const [patients, setPatients] = useState([]);
  const [apts, setApts] = useState([]);
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(empty);
  const [editId, setEditId] = useState(null);
  const [histModal, setHistModal] = useState(false);
  const [histData, setHistData] = useState(null);

  const load = () => Promise.all([api.get('/patients'), api.get('/appointments')]).then(([p, a]) => { setPatients(p.data); setApts(a.data); });
  useEffect(() => { load(); }, []);

  const filtered = patients.filter(p => `${p.firstName} ${p.lastName} ${p.phone}`.toLowerCase().includes(search.toLowerCase()));

  const openAdd = () => { setForm(empty); setEditId(null); setModal(true); };
  const openEdit = p => { setForm(p); setEditId(p.id); setModal(true); };

  const save = async () => {
    if (!form.firstName || !form.lastName) { notify("Ism va familiyani kiriting!", 'warning'); return; }
    try {
      if (editId) { await api.put(`/patients/${editId}`, form); notify('Tahrirlandi!', 'success'); }
      else { await api.post('/patients', form); notify("Qo'shildi!", 'success'); }
      setModal(false); load();
    } catch (e) { notify(e.response?.data?.error || 'Xatolik', 'danger'); }
  };

  const del = async id => {
    if (!confirm("O'chirmoqchimisiz?")) return;
    await api.delete(`/patients/${id}`); notify("O'chirildi", 'danger'); load();
  };

  const viewHistory = p => {
    const pApts = apts.filter(a => a.patientId === p.id).sort((a, b) => b.date > a.date ? 1 : -1);
    setHistData({ patient: p, apts: pApts });
    setHistModal(true);
  };

  const f = k => e => setForm(p => ({ ...p, [k]: e.target.value }));
  const regions = Object.keys(UZ_REGIONS);
  const districts = form.region ? UZ_REGIONS[form.region] || [] : [];

  return (
    <div>
      <div className="page-header">
        <h1>👥 Bemorlar</h1>
        <div style={{ display: 'flex', gap: 10 }}>
          <input className="form-control" placeholder="Qidirish..." value={search} onChange={e => setSearch(e.target.value)} style={{ width: 240 }} />
          <button className="btn btn-primary" onClick={openAdd}>+ Bemor qo'shish</button>
        </div>
      </div>

      <div className="table-wrap">
        <table>
          <thead><tr><th>#</th><th>Ism</th><th>Telefon</th><th>Viloyat</th><th>So'nggi qabul</th><th>Amal</th></tr></thead>
          <tbody>
            {filtered.length ? filtered.map((p, i) => {
              const last = apts.filter(a => a.patientId === p.id).sort((a, b) => b.date > a.date ? 1 : -1)[0];
              return (
                <tr key={p.id}>
                  <td>{i + 1}</td>
                  <td><div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><div className="av-sm">{p.firstName[0]}</div><strong>{p.firstName} {p.lastName}</strong></div></td>
                  <td>{p.phone || '—'}</td>
                  <td>{p.region ? `${p.region}${p.district ? ', ' + p.district : ''}` : '—'}</td>
                  <td>{last ? `${last.doctorName} (${formatDate(last.date)})` : '—'}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-info btn-sm" onClick={() => viewHistory(p)}>📄</button>
                      <button className="btn btn-outline btn-sm" onClick={() => openEdit(p)}>✏️</button>
                      <button className="btn btn-danger btn-sm" onClick={() => del(p.id)}>🗑️</button>
                    </div>
                  </td>
                </tr>
              );
            }) : <tr><td colSpan={6}><EmptyState text="Bemorlar yo'q" /></td></tr>}
          </tbody>
        </table>
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title={editId ? 'Bemorni tahrirlash' : "Bemor qo'shish"}
        footer={<><button className="btn btn-outline" onClick={() => setModal(false)}>Bekor</button><button className="btn btn-primary" onClick={save}>Saqlash</button></>}>
        <div className="form-row">
          <div className="form-group"><label className="form-label">Ism <span className="req">*</span></label><input className="form-control" value={form.firstName} onChange={f('firstName')} /></div>
          <div className="form-group"><label className="form-label">Familiya <span className="req">*</span></label><input className="form-control" value={form.lastName} onChange={f('lastName')} /></div>
        </div>
        <div className="form-row">
          <div className="form-group"><label className="form-label">Tug'ilgan sana</label><input className="form-control" type="date" value={form.dob} onChange={f('dob')} /></div>
          <div className="form-group"><label className="form-label">Jins</label>
            <select className="form-control" value={form.gender} onChange={f('gender')}>
              <option value="erkak">Erkak</option><option value="ayol">Ayol</option>
            </select>
          </div>
        </div>
        <div className="form-group"><label className="form-label">Telefon</label><input className="form-control" value={form.phone} onChange={f('phone')} /></div>
        <div className="form-row">
          <div className="form-group"><label className="form-label">Viloyat</label>
            <select className="form-control" value={form.region} onChange={e => setForm(p => ({ ...p, region: e.target.value, district: '' }))}>
              <option value="">— Tanlang —</option>
              {regions.map(r => <option key={r}>{r}</option>)}
            </select>
          </div>
          <div className="form-group"><label className="form-label">Tuman</label>
            <select className="form-control" value={form.district} onChange={f('district')}>
              <option value="">— Tanlang —</option>
              {districts.map(d => <option key={d}>{d}</option>)}
            </select>
          </div>
        </div>
        <div className="form-group"><label className="form-label">Manzil</label><input className="form-control" value={form.addr} onChange={f('addr')} /></div>
        <div className="form-group"><label className="form-label">Kasallik tarixi</label><textarea className="form-control" value={form.history} onChange={f('history')} rows={3} /></div>
      </Modal>

      <Modal open={histModal} onClose={() => setHistModal(false)} title={histData ? `${histData.patient.firstName} ${histData.patient.lastName} — Tarix` : ''} wide
        footer={<button className="btn btn-outline" onClick={() => setHistModal(false)}>Yopish</button>}>
        {histData && (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
              <div><div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>Telefon</div><strong>{histData.patient.phone || '—'}</strong></div>
              <div><div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>Tug'ilgan</div><strong>{formatDate(histData.patient.dob)}</strong></div>
              <div><div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>Viloyat</div><strong>{histData.patient.region || '—'}</strong></div>
              <div><div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>Manzil</div><strong>{histData.patient.addr || '—'}</strong></div>
            </div>
            {histData.patient.history && <div style={{ background: 'var(--warning-light)', border: '1px solid var(--warning)', borderRadius: 8, padding: 10, marginBottom: 14, fontSize: '.85rem' }}><strong>Kasallik tarixi:</strong> {histData.patient.history}</div>}
            <div style={{ fontWeight: 700, marginBottom: 10 }}>Qabullar ({histData.apts.length} ta):</div>
            {histData.apts.length ? histData.apts.map(a => (
              <div key={a.id} style={{ border: '1px solid var(--border)', borderRadius: 8, padding: 10, marginBottom: 7 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><strong>{a.doctorName}</strong><StatusBadge status={a.status} /></div>
                <div style={{ fontSize: '.78rem', color: 'var(--text2)', marginTop: 3 }}>{formatDate(a.date)} {a.time} · #{a.queue}</div>
                {a.doneNote && <div style={{ fontSize: '.78rem', color: 'var(--text3)', marginTop: 4, padding: 6, background: 'var(--bg3)', borderRadius: 5 }}>{a.doneNote}</div>}
              </div>
            )) : <EmptyState text="Qabul yo'q" />}
          </>
        )}
      </Modal>
    </div>
  );
}
