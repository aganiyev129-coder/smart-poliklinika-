import React, { useEffect, useState } from 'react';
import api from '../../api';
import { useAuth } from '../../context/AuthContext';
import EmptyState from '../../components/EmptyState';
import Modal from '../../components/Modal';
import { StatusBadge } from '../../components/Badge';
import { notify } from '../../components/Notify';
import { formatDate, today } from '../../utils/helpers';

export default function DocAppointments() {
  const { user } = useAuth();
  const [apts, setApts] = useState([]);
  const [filter, setFilter] = useState('all');
  const [doneModal, setDoneModal] = useState(false);
  const [doneId, setDoneId] = useState(null);
  const [doneNote, setDoneNote] = useState('');

  const load = () => api.get('/appointments').then(r => {
    const mine = r.data.filter(a => a.doctorId === (user.doctorId ?? user.id));
    setApts(mine);
  });
  useEffect(() => { load(); }, []);

  const filtered = apts.filter(a => {
    if (filter === 'today') return a.date === today();
    if (filter === 'pending') return a.status === 'pending';
    return true;
  }).sort((a, b) => b.date > a.date ? 1 : a.time > b.time ? 1 : -1);

  const openDone = id => { setDoneId(id); setDoneNote(''); setDoneModal(true); };
  const confirmDone = async () => {
    await api.patch(`/appointments/${doneId}`, { status: 'done', doneNote });
    notify('Qabul yakunlandi!', 'success');
    setDoneModal(false); load();
  };

  return (
    <div>
      <div className="page-header"><h1>📅 Mening qabullarim</h1></div>
      <div className="tab-row">
        {[['all', 'Barchasi'], ['today', 'Bugun'], ['pending', 'Kutilmoqda']].map(([v, l]) => (
          <button key={v} className={`tab-btn${filter === v ? ' active' : ''}`} onClick={() => setFilter(v)}>{l}</button>
        ))}
      </div>

      <div className="table-wrap">
        <table>
          <thead><tr><th>Navbat</th><th>Bemor</th><th>Sana/Vaqt</th><th>Holat</th><th>Izoh</th><th>Amal</th></tr></thead>
          <tbody>
            {filtered.length ? filtered.map(a => (
              <tr key={a.id}>
                <td><strong>#{a.queue}</strong></td>
                <td>{a.patientName}</td>
                <td>{formatDate(a.date)} {a.time}</td>
                <td><StatusBadge status={a.status} /></td>
                <td style={{ maxWidth: 180, fontSize: '.8rem', color: 'var(--text3)' }}>{a.doneNote || a.note || '—'}</td>
                <td>{a.status === 'pending' && <button className="btn btn-success btn-sm" onClick={() => openDone(a.id)}>✓ Yakunlash</button>}</td>
              </tr>
            )) : <tr><td colSpan={6}><EmptyState text="Qabul yo'q" /></td></tr>}
          </tbody>
        </table>
      </div>

      <Modal open={doneModal} onClose={() => setDoneModal(false)} title="Qabulni yakunlash"
        footer={<><button className="btn btn-outline" onClick={() => setDoneModal(false)}>Bekor</button><button className="btn btn-success" onClick={confirmDone}>Tasdiqlash</button></>}>
        <div className="form-group">
          <label className="form-label">Tashxis / Izoh</label>
          <textarea className="form-control" value={doneNote} onChange={e => setDoneNote(e.target.value)} rows={4} placeholder="Bemorga tashxis va ko'rsatmalar..." />
        </div>
      </Modal>
    </div>
  );
}
