import React, { useEffect, useState } from 'react';
import api from '../../api';
import { useAuth } from '../../context/AuthContext';
import EmptyState from '../../components/EmptyState';
import Modal from '../../components/Modal';
import { StatusBadge } from '../../components/Badge';
import { formatDate } from '../../utils/helpers';

export default function DocPatients() {
  const { user } = useAuth();
  const [myPatients, setMyPatients] = useState([]);
  const [apts, setApts] = useState([]);
  const [search, setSearch] = useState('');
  const [histModal, setHistModal] = useState(false);
  const [histData, setHistData] = useState(null);

  useEffect(() => {
    Promise.all([api.get('/appointments'), api.get('/patients')]).then(([aptsRes, patsRes]) => {
      const mine = aptsRes.data.filter(a => a.doctorId === user.id || a.doctorName === `${user.firstName} ${user.lastName}`);
      setApts(mine);
      const patIds = new Set(mine.map(a => a.patientId).filter(Boolean));
      setMyPatients(patsRes.data.filter(p => patIds.has(p.id)));
    });
  }, []);

  const filtered = myPatients.filter(p => `${p.firstName} ${p.lastName} ${p.phone}`.toLowerCase().includes(search.toLowerCase()));

  const viewHistory = p => {
    const pApts = apts.filter(a => a.patientId === p.id).sort((a, b) => b.date > a.date ? 1 : -1);
    setHistData({ patient: p, apts: pApts });
    setHistModal(true);
  };

  return (
    <div>
      <div className="page-header">
        <h1>👥 Mening bemorlarim</h1>
        <input className="form-control" placeholder="Qidirish..." value={search} onChange={e => setSearch(e.target.value)} style={{ width: 240 }} />
      </div>

      <div className="table-wrap">
        <table>
          <thead><tr><th>#</th><th>Ism</th><th>Telefon</th><th>So'nggi tashrif</th><th>Holat</th><th>Amal</th></tr></thead>
          <tbody>
            {filtered.length ? filtered.map((p, i) => {
              const last = apts.filter(a => a.patientId === p.id).sort((a, b) => b.date > a.date ? 1 : -1)[0];
              return (
                <tr key={p.id}>
                  <td>{i + 1}</td>
                  <td><div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><div className="av-sm">{p.firstName[0]}</div><strong>{p.firstName} {p.lastName}</strong></div></td>
                  <td>{p.phone || '—'}</td>
                  <td>{last ? formatDate(last.date) : '—'}</td>
                  <td>{last ? <StatusBadge status={last.status} /> : '—'}</td>
                  <td><button className="btn btn-info btn-sm" onClick={() => viewHistory(p)}>📄 Tarix</button></td>
                </tr>
              );
            }) : <tr><td colSpan={6}><EmptyState text="Bemorlar yo'q" /></td></tr>}
          </tbody>
        </table>
      </div>

      <Modal open={histModal} onClose={() => setHistModal(false)} title={histData ? `${histData.patient.firstName} ${histData.patient.lastName} — Tarix` : ''} wide
        footer={<button className="btn btn-outline" onClick={() => setHistModal(false)}>Yopish</button>}>
        {histData && (
          <>
            {histData.patient.history && <div style={{ background: 'var(--warning-light)', border: '1px solid var(--warning)', borderRadius: 8, padding: 10, marginBottom: 14, fontSize: '.85rem' }}><strong>Kasallik tarixi:</strong> {histData.patient.history}</div>}
            <div style={{ fontWeight: 700, marginBottom: 10 }}>Qabullar ({histData.apts.length} ta):</div>
            {histData.apts.map(a => (
              <div key={a.id} style={{ border: '1px solid var(--border)', borderRadius: 8, padding: 10, marginBottom: 7 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><strong>{formatDate(a.date)} {a.time}</strong><StatusBadge status={a.status} /></div>
                {a.doneNote && <div style={{ fontSize: '.78rem', color: 'var(--text3)', marginTop: 4, padding: 6, background: 'var(--bg3)', borderRadius: 5 }}>{a.doneNote}</div>}
              </div>
            ))}
          </>
        )}
      </Modal>
    </div>
  );
}
