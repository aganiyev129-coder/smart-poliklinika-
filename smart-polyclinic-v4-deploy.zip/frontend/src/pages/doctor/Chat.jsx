import React, { useEffect, useState, useRef, useCallback } from 'react';
import api from '../../api';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import EmptyState from '../../components/EmptyState';
import Modal from '../../components/Modal';
import { notify } from '../../components/Notify';

export default function DocChat() {
  const { user } = useAuth();
  const { joinChat, sendMessage, onMessage } = useSocket();
  const [patients, setPatients] = useState([]);
  const [activePatient, setActivePatient] = useState(null);
  const [chatKey, setChatKey] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [medModal, setMedModal] = useState(false);
  const [med, setMed] = useState({ name: '', dose: '', dur: '', note: '' });
  const msgsRef = useRef();

  useEffect(() => { api.get('/patients').then(r => setPatients(r.data)); }, []);

  // Chat key = dp_{doctorId}_{patientId}
  const openChat = async pat => {
    const key = `dp_${user.doctorId ?? user.id}_${pat.id}`;
    setActivePatient(pat);
    setChatKey(key);
    joinChat(key);
    const r = await api.get(`/chat/${key}`);
    setMessages(r.data);
  };

  useEffect(() => {
    if (!chatKey) return;
    const unsub = onMessage(msg => {
      setMessages(p => [...p, msg]);
    });
    return unsub;
  }, [chatKey, onMessage]);

  useEffect(() => {
    if (msgsRef.current) msgsRef.current.scrollTop = msgsRef.current.scrollHeight;
  }, [messages]);

  const send = () => {
    if (!input.trim() || !chatKey) return;
    const msg = { text: input.trim(), sender: 'doctor', isPrescription: false, time: new Date().toISOString() };
    sendMessage(chatKey, msg);
    setInput('');
  };

  const sendPrescription = () => {
    if (!med.name || !chatKey) { notify("Dori nomini kiriting!", 'warning'); return; }
    const text = `RETSEPT\n━━━━━━━━━━━━━━━\nDori: ${med.name}${med.dose ? '\nDozasi: ' + med.dose : ''}${med.dur ? '\nDavomiyligi: ' + med.dur : ''}${med.note ? "\nKo'rsatma: " + med.note : ''}`;
    const msg = { text, sender: 'doctor', isPrescription: true, time: new Date().toISOString() };
    sendMessage(chatKey, msg);
    setMedModal(false);
    setMed({ name: '', dose: '', dur: '', note: '' });
    notify("Retsept yuborildi!", 'success');
  };

  const onKeyDown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };

  return (
    <div>
      <div className="page-header"><h1>💬 Onlayn maslahat</h1></div>
      <div className="chat-layout" style={{ height: 'calc(100vh - 160px)' }}>
        <div className="chat-sidebar">
          <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--border)', fontWeight: 700, fontSize: '.85rem' }}>Bemorlar</div>
          {patients.length ? patients.map(p => (
            <div key={p.id} className={`chat-user-item${activePatient?.id === p.id ? ' active' : ''}`} onClick={() => openChat(p)}>
              <div className="av-sm">{p.firstName[0]}</div>
              <div style={{ minWidth: 0 }}>
                <div className="chat-user-nm">{p.firstName} {p.lastName}</div>
                <div className="chat-user-last">{p.phone || '—'}</div>
              </div>
            </div>
          )) : <EmptyState text="Bemorlar yo'q" />}
        </div>

        <div className="chat-main">
          {activePatient ? (
            <>
              <div className="chat-header">
                <div className="av-sm">{activePatient.firstName[0]}</div>
                <div>
                  <div style={{ fontWeight: 700 }}>{activePatient.firstName} {activePatient.lastName}</div>
                  <div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>{activePatient.phone || '—'}</div>
                </div>
                <button className="btn btn-success btn-sm" style={{ marginLeft: 'auto' }} onClick={() => setMedModal(true)}>💊 Retsept</button>
              </div>
              <div className="chat-msgs" ref={msgsRef}>
                {messages.length ? messages.map((m, i) => (
                  <div key={i} className={`msg ${m.sender === 'doctor' ? 'sent' : 'recv'}`}>
                    <div className={`msg-bbl${m.isPrescription ? ' prescription' : ''}`}>{m.text}</div>
                    <div className="msg-meta">{m.sender === 'doctor' ? 'Shifokor' : 'Bemor'} · {new Date(m.time).toLocaleTimeString('uz-UZ', { hour: '2-digit', minute: '2-digit' })}</div>
                  </div>
                )) : <EmptyState text="Xabar yo'q. Salom yuboring!" />}
              </div>
              <div className="chat-foot">
                <input className="form-control" value={input} onChange={e => setInput(e.target.value)} onKeyDown={onKeyDown} placeholder="Xabar yozing..." />
                <button className="btn btn-primary" onClick={send}>Yuborish</button>
              </div>
            </>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
              <EmptyState icon="💬" text="Bemor tanlang" />
            </div>
          )}
        </div>
      </div>

      <Modal open={medModal} onClose={() => setMedModal(false)} title="Retsept yozish"
        footer={<><button className="btn btn-outline" onClick={() => setMedModal(false)}>Bekor</button><button className="btn btn-success" onClick={sendPrescription}>Yuborish</button></>}>
        <div className="form-group"><label className="form-label">Dori nomi <span className="req">*</span></label><input className="form-control" value={med.name} onChange={e => setMed(p => ({ ...p, name: e.target.value }))} placeholder="Masalan: Paracetamol 500mg" /></div>
        <div className="form-row">
          <div className="form-group"><label className="form-label">Dozasi</label><input className="form-control" value={med.dose} onChange={e => setMed(p => ({ ...p, dose: e.target.value }))} placeholder="Kuniga 3 marta" /></div>
          <div className="form-group"><label className="form-label">Davomiyligi</label><input className="form-control" value={med.dur} onChange={e => setMed(p => ({ ...p, dur: e.target.value }))} placeholder="7 kun" /></div>
        </div>
        <div className="form-group"><label className="form-label">Ko'rsatmalar</label><textarea className="form-control" value={med.note} onChange={e => setMed(p => ({ ...p, note: e.target.value }))} placeholder="Ovqatdan keyin, suv bilan..." /></div>
      </Modal>
    </div>
  );
}
