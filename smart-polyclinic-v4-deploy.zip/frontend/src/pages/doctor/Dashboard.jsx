import React, { useEffect, useState } from 'react';
import api from '../../api';
import { useAuth } from '../../context/AuthContext';
import { today, formatDate } from '../../utils/helpers';
import { StatusBadge } from '../../components/Badge';
import EmptyState from '../../components/EmptyState';
import Modal from '../../components/Modal';
import { notify } from '../../components/Notify';

export default function DocDashboard() {
  const { user } = useAuth();
  const [apts, setApts] = useState([]);
  const [doneModal, setDoneModal] = useState(false);
  const [doneId, setDoneId] = useState(null);
  const [doneNote, setDoneNote] = useState('');

  const load = () => {
    api.get('/appointments').then(r => {
      const mine = r.data.filter(a => a.doctorId === (user.doctorId ?? user.id));
      setApts(mine);
    });
  };
  useEffect(() => { load(); }, []);

  const todayApts = apts.filter(a => a.date === today());
  const patIds = new Set(apts.map(a => a.patientId).filter(Boolean));

  const openDone = id => { setDoneId(id); setDoneNote(''); setDoneModal(true); };
  const confirmDone = async () => {
    await api.patch(`/appointments/${doneId}`, { status: 'done', doneNote });
    notify('Qabul yakunlandi!', 'success');
    setDoneModal(false); load();
  };

  return (
    <div>
      <div className="stat-grid">
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--primary-light)' }}>📅</div><div><div className="stat-val">{todayApts.length}</div><div className="stat-lbl">Bugun qabullar</div></div></div>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--warning-light)' }}>⏳</div><div><div className="stat-val">{todayApts.filter(a => a.status === 'pending').length}</div><div className="stat-lbl">Kutilmoqda</div></div></div>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--success-light)' }}>✅</div><div><div className="stat-val">{apts.filter(a => a.status === 'done').length}</div><div className="stat-lbl">Jami tugallangan</div></div></div>
        <div className="stat-card"><div className="stat-icon" style={{ background: 'var(--info-light)' }}>👥</div><div><div className="stat-val">{patIds.size}</div><div className="stat-lbl">Bemorlarim</div></div></div>
      </div>

      <div className="card">
        <div className="card-title">📅 Bugungi qabullar</div>
        {todayApts.length ? (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Navbat</th><th>Bemor</th><th>Vaqt</th><th>Holat</th><th>Amal</th></tr></thead>
              <tbody>
                {todayApts.map(a => (
                  <tr key={a.id}>
                    <td><strong>#{a.queue}</strong></td>
                    <td>{a.patientName}</td>
                    <td>{a.time}</td>
                    <td><StatusBadge status={a.status} /></td>
                    <td>{a.status === 'pending' && <button className="btn btn-success btn-sm" onClick={() => openDone(a.id)}>✓ Yakunlash</button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <EmptyState text="Bugun qabul yo'q" />}
      </div>

      <Modal open={doneModal} onClose={() => setDoneModal(false)} title="Qabulni yakunlash"
        footer={<><button className="btn btn-outline" onClick={() => setDoneModal(false)}>Bekor</button><button className="btn btn-success" onClick={confirmDone}>Tasdiqlash</button></>}>
        <div className="form-group">
          <label className="form-label">Tashxis / Izoh</label>
          <textarea className="form-control" value={doneNote} onChange={e => setDoneNote(e.target.value)} rows={4} placeholder="Bemorga tashxis va ko'rsatmalar..." />
        </div>
      </Modal>
    </div>
  );
}
