import React, { useState, useEffect } from 'react';
import api from '../../api';
import { formatMoney } from '../../utils/helpers';
import { SYMPTOM_MAP } from '../../utils/constants';
import { notify } from '../../components/Notify';

const QUICK = ["Bosh og'riq", "Yurak urishi", "Qorin og'riq", "Ko'z og'riq", "Orqa og'riq", "Isitma", "Charchoq"];

export default function AI() {
  const [symptoms, setSymptoms] = useState('');
  const [age, setAge] = useState('');
  const [result, setResult] = useState(null);
  const [doctors, setDoctors] = useState([]);

  const analyze = async () => {
    if (!symptoms.trim()) { notify("Simptomlarni kiriting!", 'warning'); return; }
    if (!doctors.length) {
      const r = await api.get('/doctors');
      setDoctors(r.data);
      return runAnalysis(symptoms.toLowerCase(), parseInt(age) || 0, r.data);
    }
    runAnalysis(symptoms.toLowerCase(), parseInt(age) || 0, doctors);
  };

  const runAnalysis = async (symp, ageNum, docList) => {
    if (!docList.length) {
      const r = await api.get('/doctors');
      setDoctors(r.data);
      docList = r.data;
    }
    const found = {};
    for (const [kw, specs] of Object.entries(SYMPTOM_MAP)) {
      if (symp.includes(kw)) specs.forEach(s => found[s] = (found[s] || 0) + 1);
    }
    if (ageNum > 0 && ageNum < 14) found['Pediatr'] = (found['Pediatr'] || 0) + 3;

    const sorted = Object.entries(found).sort((a, b) => b[1] - a[1]);
    if (!sorted.length) {
      setResult({ type: 'fallback' });
      return;
    }

    const recs = sorted.slice(0, 3).map(([spec, sc]) => {
      const doc = docList.find(d => d.spec === spec);
      return { spec, score: Math.min(sc * 28 + 20, 99), doc };
    });
    setResult({ type: 'found', recs });
    notify('AI tahlili bajarildi', 'info');
  };

  const quick = s => { setSymptoms(s); setTimeout(() => runAnalysis(s.toLowerCase(), parseInt(age) || 0, doctors), 100); };
  useEffect(() => { api.get('/doctors').then(r => setDoctors(r.data)); }, []);

  return (
    <div style={{ maxWidth: 640 }}>
      <div className="page-header"><h1>🤖 AI Yordamchi</h1></div>

      <div className="ai-card">
        <div style={{ fontWeight: 700, marginBottom: 10 }}>Simptomlaringizni kiriting:</div>
        <div className="quick-chips">
          {QUICK.map(s => <div key={s} className="chip" onClick={() => quick(s)}>{s}</div>)}
        </div>
        <div className="form-row" style={{ marginBottom: 10 }}>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Simptomlar</label>
            <textarea className="form-control" value={symptoms} onChange={e => setSymptoms(e.target.value)} placeholder="Masalan: bosh og'riq, isitma, charchoq..." rows={3} />
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Yosh</label>
            <input className="form-control" type="number" value={age} onChange={e => setAge(e.target.value)} placeholder="Masalan: 35" min={1} max={120} />
          </div>
        </div>
        <button className="btn btn-primary" onClick={analyze}>🔍 Tahlil qilish</button>
      </div>

      {result && (
        <div className="ai-result-card">
          {result.type === 'fallback' ? (
            <div style={{ background: 'var(--warning-light)', border: '1px solid var(--warning)', borderRadius: 'var(--radius-xs)', padding: 12, fontSize: '.88rem' }}>
              Aniq shifokor tavsiya qila olmadim. <strong>Terapevt</strong> bilan maslahatlashing.
            </div>
          ) : (
            <>
              <div style={{ fontWeight: 700, marginBottom: 12, color: 'var(--success)' }}>AI tahlili natijasi:</div>
              {result.recs.map(({ spec, score, doc }, i) => (
                <div key={spec} className="ai-rec-item">
                  <div className={`ai-rec-num${i === 0 ? ' first' : ''}`}>{i + 1}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700 }}>{spec}</div>
                    {doc ? <div style={{ fontSize: '.78rem', color: 'var(--text2)' }}>Dr. {doc.firstName} {doc.lastName} — {formatMoney(doc.price)}</div>
                      : <div style={{ fontSize: '.78rem', color: 'var(--text3)' }}>Ushbu mutaxassis hozir yo'q</div>}
                  </div>
                  <span className="badge badge-success">{score}%</span>
                </div>
              ))}
              <div style={{ fontSize: '.75rem', color: 'var(--text3)', marginTop: 10 }}>* Faqat tavsiya. To'liq tashxis uchun shifokorga murojaat qiling.</div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

