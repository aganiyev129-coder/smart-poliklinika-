import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { NotifyContainer, notify } from '../components/Notify';

const roles = [
  { id: 'superadmin', label: 'Super Admin', icon: '👑' },
  { id: 'registrar', label: 'Registrator', icon: '📋' },
  { id: 'doctor', label: 'Shifokor', icon: '🩺' },
  { id: 'patient', label: 'Bemor', icon: '🧑' },
];

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState('superadmin');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async e => {
    e.preventDefault();
    if (!username || !password) { notify('Username va parolni kiriting!', 'warning'); return; }
    setLoading(true);
    try {
      const user = await login(username, password, role);
      notify(`Xush kelibsiz, ${user.firstName}!`, 'success');
      if (user.role === 'superadmin') navigate('/app/admin/dashboard');
      else if (user.role === 'registrar') navigate('/app/registrar/dashboard');
      else if (user.role === 'doctor') navigate('/app/doctor/dashboard');
    } catch (err) {
      notify(err.response?.data?.error || "Noto'g'ri ma'lumotlar!", 'danger');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-wrap">
        <div className="login-card">
          <div className="login-header">
            <div className="login-logo-circle">🏥</div>
            <div className="login-title">Aqlli Poliklinika</div>
            <div className="login-sub">Tizimga kirish uchun rolni tanlang</div>
          </div>

          <div className="role-grid">
            {roles.map(r => (
              <button
                key={r.id}
                type="button"
                className={`role-btn${role === r.id ? ' active' : ''}`}
                onClick={() => {
                  setRole(r.id);
                  if (r.id === 'patient') navigate('/patient');
                }}
              >
                <span className="role-icon">{r.icon}</span>
                {r.label}
              </button>
            ))}
          </div>

          {role !== 'patient' && (
            <form onSubmit={handleLogin}>
              <div className="form-group">
                <label className="form-label">Username <span className="req">*</span></label>
                <input className="form-control" value={username} onChange={e => setUsername(e.target.value)} placeholder="Username kiriting" autoComplete="username" />
              </div>
              <div className="form-group">
                <label className="form-label">Parol <span className="req">*</span></label>
                <input className="form-control" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Parol kiriting" autoComplete="current-password" />
              </div>
              <button className="btn btn-primary btn-block btn-lg" type="submit" disabled={loading}>
                {loading ? 'Kirish...' : '→ Kirish'}
              </button>
            </form>
          )}

          <div style={{ marginTop: 16, fontSize: '.72rem', color: 'var(--text3)', textAlign: 'center' }}>
            Demo: admin/admin123 · reg/reg123 · doc/doc123
          </div>
        </div>
      </div>
      <NotifyContainer />
    </div>
  );
}
