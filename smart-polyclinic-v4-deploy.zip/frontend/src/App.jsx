import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';

import Login from './pages/Login';
import PatientPortal from './pages/patient/Portal';
import Layout from './components/Layout';

import AdminDashboard from './pages/admin/Dashboard';
import AdminDoctors from './pages/admin/Doctors';
import AdminPatients from './pages/admin/Patients';
import AdminUsers from './pages/admin/Users';
import AdminReports from './pages/admin/Reports';
import AdminLogs from './pages/admin/Logs';
import AdminSettings from './pages/admin/Settings';

import RegDashboard from './pages/registrar/Dashboard';
import RegPatients from './pages/registrar/Patients';
import RegAppointments from './pages/registrar/Appointments';
import RegPayment from './pages/registrar/Payment';

import DocDashboard from './pages/doctor/Dashboard';
import DocPatients from './pages/doctor/Patients';
import DocAppointments from './pages/doctor/Appointments';
import DocChat from './pages/doctor/Chat';

import AI from './pages/shared/AI';

function RoleRoute({ children, roles }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/app" replace />;
  return children;
}

function AppRedirect() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'superadmin') return <Navigate to="/app/admin/dashboard" replace />;
  if (user.role === 'registrar') return <Navigate to="/app/registrar/dashboard" replace />;
  if (user.role === 'doctor') return <Navigate to="/app/doctor/dashboard" replace />;
  return <Navigate to="/login" replace />;
}

function ProtectedLayout() {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) return <Navigate to="/login" replace />;
  return (
    <SocketProvider>
      <Layout />
    </SocketProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/patient" element={<PatientPortal />} />
          <Route path="/app" element={<ProtectedLayout />}>
            <Route index element={<AppRedirect />} />
            {/* Admin */}
            <Route path="admin/dashboard" element={<RoleRoute roles={['superadmin']}><AdminDashboard /></RoleRoute>} />
            <Route path="admin/doctors" element={<RoleRoute roles={['superadmin']}><AdminDoctors /></RoleRoute>} />
            <Route path="admin/patients" element={<RoleRoute roles={['superadmin']}><AdminPatients /></RoleRoute>} />
            <Route path="admin/users" element={<RoleRoute roles={['superadmin']}><AdminUsers /></RoleRoute>} />
            <Route path="admin/reports" element={<RoleRoute roles={['superadmin']}><AdminReports /></RoleRoute>} />
            <Route path="admin/logs" element={<RoleRoute roles={['superadmin']}><AdminLogs /></RoleRoute>} />
            <Route path="admin/settings" element={<RoleRoute roles={['superadmin']}><AdminSettings /></RoleRoute>} />
            {/* Registrar */}
            <Route path="registrar/dashboard" element={<RoleRoute roles={['registrar']}><RegDashboard /></RoleRoute>} />
            <Route path="registrar/patients" element={<RoleRoute roles={['registrar']}><RegPatients /></RoleRoute>} />
            <Route path="registrar/appointments" element={<RoleRoute roles={['registrar']}><RegAppointments /></RoleRoute>} />
            <Route path="registrar/payment" element={<RoleRoute roles={['registrar']}><RegPayment /></RoleRoute>} />
            {/* Doctor */}
            <Route path="doctor/dashboard" element={<RoleRoute roles={['doctor']}><DocDashboard /></RoleRoute>} />
            <Route path="doctor/patients" element={<RoleRoute roles={['doctor']}><DocPatients /></RoleRoute>} />
            <Route path="doctor/appointments" element={<RoleRoute roles={['doctor']}><DocAppointments /></RoleRoute>} />
            <Route path="doctor/chat" element={<RoleRoute roles={['doctor']}><DocChat /></RoleRoute>} />
            {/* Shared */}
            <Route path="ai" element={<AI />} />
          </Route>
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
