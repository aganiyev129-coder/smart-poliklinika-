export const UZ_REGIONS = {
  'Toshkent shahri': ["Bektemir tumani","Chilonzor tumani","Mirobod tumani","Mirzo Ulug'bek tumani","Olmazor tumani","Sergeli tumani","Shayxontohur tumani","Uchtepa tumani","Yakkasaroy tumani","Yashnobod tumani","Yunusobod tumani"],
  'Toshkent viloyati': ["Angren shahri","Bekobod shahri","Chirchiq shahri","Nurafshon shahri","Bo\u02bca tumani","Bo\u02bcstonliq tumani","Zangiota tumani","Ohangaron tumani","Parkent tumani","Piskent tumani","Qibray tumani","Toshkent tumani","Yangiy\u014bl tumani"],
  'Andijon viloyati': ["Andijon shahri","Asaka shahri","Xonobod shahri","Andijon tumani","Asaka tumani","Baliqchi tumani","Jalaquduq tumani","Marhamat tumani","Oltinkol tumani","Paxtaobod tumani","Shahrixon tumani","Ulug'nor tumani"],
  "Farg'ona viloyati": ["Farg'ona shahri","Marg'ilon shahri","Qo'qon shahri","Quvasoy shahri","Oltiariq tumani","Beshariq tumani","Buvayda tumani","Farg'ona tumani","Rishton tumani","Sox tumani","Toshloq tumani","Uchko'prik tumani","Yozyovon tumani"],
  'Namangan viloyati': ["Namangan shahri","Chortoq shahri","Chust shahri","Pop shahri","Namangan tumani","Chortoq tumani","Kosonsoy tumani","Mingbuloq tumani","Norin tumani","Pop tumani","To'raqo'rg'on tumani"],
  'Samarqand viloyati': ["Samarqand shahri","Kattaqo'rg'on shahri","Bulung'ur tumani","Ishtixon tumani","Jomboy tumani","Kattaqo'rg'on tumani","Narpay tumani","Oqdaryo tumani","Pastdarg'om tumani","Samarqand tumani","Tayloq tumani","Urgut tumani"],
  'Buxoro viloyati': ["Buxoro shahri","G'ijduvon shahri","Kogon shahri","Buxoro tumani","G'ijduvon tumani","Jondor tumani","Kogon tumani","Olot tumani","Qorakol tumani","Romitan tumani","Shofirkon tumani","Vobkent tumani"],
  'Qashqadaryo viloyati': ["Qarshi shahri","Shahrisabz shahri","G'uzor shahri","Dehqonobod tumani","G'uzor tumani","Kasbi tumani","Kitob tumani","Koson tumani","Muborak tumani","Nishon tumani","Qarshi tumani","Chiroqchi tumani","Shahrisabz tumani"],
  'Surxondaryo viloyati': ["Termiz shahri","Boysun tumani","Denov tumani","Jarqo'rg'on tumani","Muzrabot tumani","Oltinsoy tumani","Qiziriq tumani","Qumqo'rg'on tumani","Sariosiyo tumani","Sherobod tumani","Termiz tumani","Uzun tumani"],
  'Jizzax viloyati': ["Jizzax shahri","Arnasoy tumani","Baxmal tumani","Do'stlik tumani","Forish tumani","G'allaorol tumani","Jizzax tumani","Paxtakor tumani","Yangiobod tumani","Zomin tumani","Zarbdor tumani"],
  'Sirdaryo viloyati': ["Guliston shahri","Sirdaryo shahri","Boyovut tumani","Guliston tumani","Mirzaobod tumani","Oqoltin tumani","Sardoba tumani","Sirdaryo tumani","Xovos tumani"],
  'Navoiy viloyati': ["Navoiy shahri","Zarafshon shahri","Karmana tumani","Konimex tumani","Navbahor tumani","Nurota tumani","Qiziltepa tumani","Tomdi tumani","Uchquduq tumani","Xatirchi tumani"],
  'Xorazm viloyati': ["Urganch shahri","Xiva shahri","Bog'ot tumani","Gurlan tumani","Xiva tumani","Xonqa tumani","Qo'shko'pir tumani","Shovot tumani","Urganch tumani","Yangiariq tumani","Yangibozor tumani"],
  "Qoraqalpog'iston Respublikasi": ["Nukus shahri","Amudaryo tumani","Beruniy tumani","Chimboy tumani","Ellikqal'a tumani","Kegeyli tumani","Mo'ynoq tumani","Nukus tumani","Qanlikoʻl tumani","Qoʻng'irot tumani","Shumanay tumani","Taxtako'pir tumani","To'rtko'l tumani","Xo'jayli tumani"]
};

export const SYMPTOM_MAP = {
  "bosh og'riq": ['Neyropatolog','Terapevt'],
  'bosh': ['Neyropatolog','Terapevt'],
  'migren': ['Neyropatolog'],
  'isitma': ['Terapevt','Pediatr'],
  "yo'tal": ['Terapevt'],
  'burun oqish': ['Terapevt'],
  "ko'ngil aynish": ['Terapevt','Gastroenterolog'],
  "qorin og'riq": ['Terapevt','Xirurg'],
  'ich ket': ['Terapevt'],
  "ko'z og'riq": ['Oftalmolog'],
  "ko'z qizarish": ['Oftalmolog'],
  "tish og'riq": ['Stomatolog'],
  'charchoq': ['Terapevt','Endokrinolog'],
  'zaiflik': ['Terapevt'],
  'bosh aylanish': ['Neyropatolog'],
  'yurak urishi': ['Kardiolog'],
  'nafas qisishi': ['Kardiolog','Terapevt'],
  "ko'krak og'riq": ['Kardiolog'],
  'teri qichishi': ['Dermatolog'],
  'toshma': ['Dermatolog'],
  "orqa og'riq": ['Neyropatolog','Xirurg'],
  "bo'g'im og'riq": ['Ortoped'],
  'siydik': ['Urolog'],
  'buyrak': ['Urolog'],
  'hayz': ['Ginekolog'],
  'homila': ['Ginekolog'],
  'bola': ['Pediatr'],
  'psixologik': ['Psixiatr'],
  'ruhiy': ['Psixiatr'],
  'qand': ['Endokrinolog'],
  'temir': ['Endokrinolog']
};

export const ROLE_NAMES = {
  superadmin: 'Super Admin',
  registrar: 'Registrator',
  doctor: 'Shifokor'
};

export const SPECS = [
  'Terapevt','Kardiolog','Neyropatolog','Ortoped','Xirurg',
  'Ginekolog','Pediatr','Stomatolog','Oftalmolog','Dermatolog',
  'Urolog','Endokrinolog','Gastroenterolog','Psixiatr','LOR'
];
