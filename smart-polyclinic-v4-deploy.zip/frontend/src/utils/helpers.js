export function formatDate(d) {
  if (!d) return '—';
  try { return new Date(d + 'T00:00:00').toLocaleDateString('uz-UZ', { day: '2-digit', month: '2-digit', year: 'numeric' }); }
  catch { return d; }
}

export function formatMoney(n) {
  return Number(n || 0).toLocaleString('uz-UZ') + " so'm";
}

export function genSlots(start = '08:00', end = '17:00') {
  const slots = [];
  let [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  while (sh * 60 + sm < eh * 60 + em - 20) {
    const isLunch = sh === 13 && sm < 30;
    if (!isLunch) slots.push(`${String(sh).padStart(2,'0')}:${String(sm).padStart(2,'0')}`);
    sm += 30;
    if (sm >= 60) { sh++; sm -= 60; }
  }
  return slots;
}

export function today() {
  return new Date().toISOString().slice(0, 10);
}

export function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

export function statusLabel(s) {
  return { pending: "Kutilmoqda", done: "Tugallangan", cancelled: "Bekor qilindi" }[s] || s;
}

export function statusClass(s) {
  return { pending: 'badge-warning', done: 'badge-success', cancelled: 'badge-danger' }[s] || 'badge-info';
}
