# Aqlli Poliklinika Tizimi v4 — Full Stack

React + Node.js + SQLite + Socket.io

## Ishga tushirish

### 1. Backend
```bash
cd backend
npm install
npm run dev
```
Backend: http://localhost:3001

### 2. Frontend (yangi terminal)
```bash
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173

## Demo hisoblar

| Rol         | Username | Parol    |
|-------------|----------|----------|
| Super Admin | admin    | admin123 |
| Registrator | reg      | reg123   |
| Shifokor    | doc      | doc123   |
| Bemor       | —        | Portal orqali |

## Bemor portali

http://localhost:5173/patient

## Arxitektura

```
backend/
  src/
    index.js          # Express + Socket.io server
    db.js             # SQLite (node:sqlite)
    middleware/auth.js # JWT middleware
    routes/           # API routes

frontend/
  src/
    pages/admin/      # Super Admin sahifalari
    pages/registrar/  # Registrator sahifalari
    pages/doctor/     # Shifokor sahifalari
    pages/patient/    # Bemor portali
    pages/shared/     # AI Yordamchi
    components/       # Shared components
    context/          # Auth + Socket context
```
